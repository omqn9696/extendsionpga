// ==UserScript==
// @name         Show timer
// @namespace    pixels
// @icon         https://img.icons8.com/water-color/50/coming-soon.png
// @version      4.1
// @description  
// @author       GAOOM.AI
// @match        https://pixels.guildpal.com/
// @match        https://play.pixels.xyz/
// @grant        unsafeWindow
// @require      https://cdn.jsdelivr.net/npm/pako@2.1.0/dist/pako.min.js
// ==/UserScript==

(function() {
    'use strict';

    const decodeTimers = (base64Str) => {
        try {
            const bytes = Uint8Array.from(atob(base64Str), c => c.charCodeAt(0));
            return JSON.parse(pako.inflate(bytes, { to: "string" }));
        } catch (error) {
            console.warn("❌ Lỗi decodeTimers:", error);
            return null;
        }
    };

    const filterMineTimers = (timersData) => {
        try {
            const filtered = timersData.filter(
                (t) =>
                    t.entity?.startsWith("ent_saunarocks_charger") &&
                    t.mapId &&
                    !t.mapId.startsWith("shareRent")
            );

            if (!filtered.length) return [];

            return filtered.map((t) => ({
                mapId: t.mapId.replace("pixelsNFTFarm-", ""),
                entity: t.entity,
                endTime: t.endTime
            }));
        } catch (err) {
            console.warn("❌ Lỗi filterMineTimers:", err);
            return [];
        }
    };

    const fetchTimers = async () => {
        const pid = "6602a183ca1af871f122cc9b";

        try {
            const res = await fetch("https://api-pixels.guildpal.com/stats-api/timers/gettimers", {
                method: "GET",
                headers: {
                    "x-atomrigs-pga-pid": pid,
                    "x-atomrigs-pga-version": "1.1.4"
                }
            });

            const data = await res.json();


            if (data?.data?.timers) {

                const decoded = decodeTimers(data.data.timers);
                const raw =  filterMineTimers(decoded);
                return raw;
            }
        } catch (err) {
            console.warn("❌ Fetch timers failed:", err);
        }
    };

    // ---- CHỈ CHẠY 1 LẦN ----
    (async () => {
        unsafeWindow.timerscheck = await fetchTimers();
    })();

})();
(function () {
    const ctx = window.pga?.drawing?.canvasContext;
    const cvs = window.pga?.drawing?.canvas;
    if (!ctx || !cvs) return console.log("No canvas");

    const icon = new Image();
    icon.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACHRwTkdHTEQzAAAAAEqAKR8AAAAGYktHRAD/AP8A/6C9p5MAAAFmSURBVHicxZahbgJBFEWHpvAbNYimOAyGpKKGfgBo0pCQVNWUBFXfJv2BSsQmuCr4AkBVVdUWB75yyN3kwbLdN/OG3bdMcjOIyZ5zJ7OzmCiKzDlTyEO6H8Yid+NDVAUIiIwXxv7a1r+QUOECeHAWkItPQhU+fbVxXBIXJmDUG/K1y7fV/vfVp+UXarSn5pSHG8vugFiAO2x54GIBaftQuFhA0j4Nb9emorvAuwAnWAsuEvBt/ynbLhaQtE+KAB7SXnwPfG+/nDPe+fWPMZ2+/J4Q3wP0cZltqnHT9Izm7wO7n0N3wLvgfvgYw7ICYDKhcK9ACPz68jkYLjqEmnCnANe+iG0XCaA9bkBAs2aC52nPCqC9D/7Uzr/9TgEKgMkAnIyKAHLb66vDWYGy4KwAHUBteKZAur0mHHF+jP5Gx38m56uReZk0Kyd8ctjBCpQBjwd3CDW3XfQaAqoNdwqQhCbcK1BGdi37w7h38p/oAAAAAElFTkSuQmCC";
    let loaded = false;

    icon.onload = () => {
        loaded = true;
        loop();
    };
    unsafeWindow.formatTime = formatTime

    // Format thời gian
    function formatTime(endTime) {
        let remain = endTime - Date.now();
        if (remain < 0) remain = 0;

        const sec = Math.floor(remain / 1000);
        const m = Math.floor(sec / 60);
        const s = sec % 60;
        const h = Math.floor(m / 60);
        const mm = m % 60;

        if (h >= 1) return `${h}:${mm.toString().padStart(2, "0")}`;
        return `${mm}:${s.toString().padStart(2, "0")}`;
    }

    function drawTimer() {
        if (!loaded) return;
        if (!window.timerscheck || window.timerscheck.length === 0) return;

        const data = window.timerscheck[0];
        const text = formatTime(data.endTime);

        // ---- Layout ----
        const ICON_W = 32;
        const ICON_H = 32;
        const padding = 10;
        const spacing = 6;  // icon -> text

        // Text size
        ctx.font = "20px Arial";
        const textW = ctx.measureText(text).width;
        const textH = 20;

        // Box size
        const boxW = Math.max(ICON_W, textW) + padding * 2;
        const boxH = ICON_H + textH + spacing + padding * 2;

        const boxX = (cvs.width / 2) - (boxW / 2);
        const boxY = 10;

        // ---- Draw Background ----
        ctx.save();
        ctx.fillStyle = "rgba(0,0,0,0.55)";
        ctx.strokeStyle = "rgba(255,255,255,0.25)";
        ctx.lineWidth = 2;

        // bo góc
        const r = 10;
        ctx.beginPath();
        ctx.moveTo(boxX + r, boxY);
        ctx.lineTo(boxX + boxW - r, boxY);
        ctx.quadraticCurveTo(boxX + boxW, boxY, boxX + boxW, boxY + r);
        ctx.lineTo(boxX + boxW, boxY + boxH - r);
        ctx.quadraticCurveTo(boxX + boxW, boxY + boxH, boxX + boxW - r, boxY + boxH);
        ctx.lineTo(boxX + r, boxY + boxH);
        ctx.quadraticCurveTo(boxX, boxY + boxH, boxX, boxY + boxH - r);
        ctx.lineTo(boxX, boxY + r);
        ctx.quadraticCurveTo(boxX, boxY, boxX + r, boxY);
        ctx.closePath();

        // shadow
        ctx.shadowColor = "rgba(0,0,0,0.6)";
        ctx.shadowBlur = 8;
        ctx.shadowOffsetY = 3;

        ctx.fill();
        ctx.stroke();
        ctx.restore();

        // ---- Draw Icon ----
        const iconX = boxX + boxW / 2 - ICON_W / 2;
        const iconY = boxY + padding;

        ctx.drawImage(icon, iconX, iconY, ICON_W, ICON_H);

        // ---- Draw Text ----
        ctx.fillStyle = "white";
        ctx.textAlign = "center";
        ctx.font = "20px Arial";

        ctx.fillText(
            text,
            boxX + boxW / 2,
            iconY + ICON_H + spacing + textH
        );
    }

    function loop() {
        requestAnimationFrame(loop);
        drawTimer();
    }
})();
