// ==UserScript==
// @name         UI
// @namespace    http://tampermonkey.net/
// @version      2025-12-07
// @description  try to take over the world!
// @author       You
// @match        https://dashboard.pixels.xyz/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=pixels.xyz
// @grant        GM_registerMenuCommand
// ==/UserScript==

(function () {

    // ----- 1) TẠO HTML PAGE LOCAL -----
    const settingsHTML = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Local Settings</title>
            <style>
                body {
                    background: #111;
                    color: white;
                    font-family: Arial;
                    padding: 20px;
                }
                h2 { margin-top: 0; }
                label { display: block; margin: 10px 0; }
            </style>
        </head>
        <body>
            <h2>⚙ Settings</h2>

            <label>
                <input type="checkbox" id="autoMine"> Auto Mine
            </label>

            <label>
                <input type="checkbox" id="autoRun"> Auto Run
            </label>

            <button id="saveBtn">Save</button>

            <script>
                // Load settings
                document.getElementById("autoMine").checked = localStorage.getItem("autoMine") === "1";
                document.getElementById("autoRun").checked = localStorage.getItem("autoRun") === "1";

                // Save
                document.getElementById("saveBtn").onclick = () => {
                    localStorage.setItem("autoMine", document.getElementById("autoMine").checked ? "1" : "0");
                    localStorage.setItem("autoRun", document.getElementById("autoRun").checked ? "1" : "0");
                    alert("Saved!");
                };
            </script>
        </body>
        </html>
    `;

    // Tạo Blob URL từ HTML (local 100%, không cần file ngoài)
    const blob = new Blob([settingsHTML], { type: "text/html" });
    const SETTINGS_URL = URL.createObjectURL(blob);


    // ----- 2) POPUP UI -----
    function createPopup() {
        if (document.querySelector("#tm-popup-settings")) return;

        const popup = document.createElement("div");
        popup.id = "tm-popup-settings";
        popup.style.cssText = `
            position: fixed;
            top: 100px;
            left: 100px;
            width: 500px;
            height: 400px;
            background: #1b1b1bcc;
            border: 1px solid #444;
            border-radius: 10px;
            z-index: 999999999999;
            padding: 0;
            backdrop-filter: blur(6px);
        `;

        const closeBtn = document.createElement("div");
        closeBtn.innerText = "✖";
        closeBtn.style.cssText = `
            position: absolute;
            right: 10px;
            top: 5px;
            cursor: pointer;
            color: white;
            font-size: 20px;
            z-index: 999999999;
        `;
        closeBtn.onclick = () => popup.remove();

        const iframe = document.createElement("iframe");
        iframe.src = SETTINGS_URL;
        iframe.style.cssText = `
            width: 100%;
            height: 100%;
            border: none;
            border-radius: 10px;
        `;

        popup.appendChild(closeBtn);
        popup.appendChild(iframe);
        document.body.appendChild(popup);

        makeDraggable(popup);
    }

    // ----- Drag popup -----
    function makeDraggable(el) {
        let dragging = false, offsetX = 0, offsetY = 0;

        el.addEventListener("mousedown", (e) => {
            dragging = true;
            offsetX = e.clientX - el.offsetLeft;
            offsetY = e.clientY - el.offsetTop;
        });

        document.addEventListener("mouseup", () => dragging = false);
        document.addEventListener("mousemove", (e) => {
            if (!dragging) return;
            el.style.left = (e.clientX - offsetX) + "px";
            el.style.top = (e.clientY - offsetY) + "px";
        });
    }

    // ----- 3) Menu Command -----
    GM_registerMenuCommand("Open Local Settings", () => {
        createPopup();
    });

})();