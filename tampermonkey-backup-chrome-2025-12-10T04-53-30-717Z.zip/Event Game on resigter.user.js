// ==UserScript==
// @name         Event Game on resigter
// @version      1.4
// @namespace    pixels
// @description  Gán các sự kiện vào window
// @icon         https://img.icons8.com/external-flaticons-lineal-color-flat-icons/64/external-events-productivity-flaticons-lineal-color-flat-icons.png
// @author       GaoOM.AI
// @match        *://play.pixels.xyz/*
// @updateURL    https://raw.githubusercontent.com/omqn9696/extendsionpga/refs/heads/main/trigerphaser.user.js
// @downloadURL  https://raw.githubusercontent.com/omqn9696/extendsionpga/refs/heads/main/trigerphaser.meta.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 🔥 Bật/tắt log tại đây
    window.logEventGame = false;

    function hookPhaserEvents() {
        const EE = window.Phaser?.Events?.EventEmitter;
        if (!EE) return console.warn("Không tìm thấy Phaser.Events.EventEmitter");

        const origEmit = EE.prototype.emit;

        const skip = [
            "render","prerender","preupdate","update","postupdate",
            "removedfromscene","addedtoscene",
            "PLAYER_QUESTPROGRESS_ADDED","PLAYER_ACHIEVEMENT_ADD",
            "PLAYER_LEVEL_ADD","ROOM_LEVEL_ADD"
        ];

        const eventTriggers = {};

        window.onGameEvent = function(eventName, callback) {
            if (!eventTriggers[eventName]) eventTriggers[eventName] = [];
            eventTriggers[eventName].push(callback);
        };
        window.emitGameEvent = function(name, ...args) {
            try {
                const EE = window.Phaser?.Events?.EventEmitter;
                if (!EE) return console.warn("Không tìm thấy EventEmitter");

                const emitter = new EE();
                emitter.emit(name, ...args);
            } catch (e) {
                console.error("Emit lỗi:", e);
            }
        };
        // Hook emit
        EE.prototype.emit = function(event, ...args) {

            // 🔥 CHỈ LOG KHI window.logEventGame = true
            if (window.logEventGame && !skip.includes(event)) {
                console.log(
                    "%c[GAME EVENT]%c",
                    "color:#00ffcc;font-weight:bold;",
                    "",
                    event,
                    ...args
                );
            }

            if (!skip.includes(event) && eventTriggers[event]) {
                eventTriggers[event].forEach(cb => {
                    try { cb(...args); } catch (e) { console.error(e); }
                });
            }

            return origEmit.apply(this, [event, ...args]);
        };
    }

    const checkInterval = setInterval(() => {
        if (window.Phaser?.Events?.EventEmitter) {
            clearInterval(checkInterval);
            hookPhaserEvents();
        }
    }, 500);

})();
/*pga.helpers.getRoomScene().movementPointer = {
                            x: 2000,
                            y: 1000
                        }*/