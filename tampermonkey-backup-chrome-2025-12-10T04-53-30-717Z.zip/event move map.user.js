// ==UserScript==
// @name         event move map
// @namespace    pixels
// @icon          https://img.icons8.com/color/48/shopaholic.png
// @version      1.3
// @description  tự động qs 60S
// @author       Drayke
// @match        *://play.pixels.xyz/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    //window.debug = window.pga.helpers.getRoomScene().drawGrid()
    function delay(ms) {
        return new Promise(r => setTimeout(r, ms));
    }
    window.addEventListener("message", async (ev) => {
        if (ev?.data?.func !== "updateCurrentRoomInfo") return;

        const mapid = window.pga?.gameState?.mapId;
        if (!mapid) return;
        if((mapid.startsWith('pixelsNFTFarm')|| mapid === "terravilla") && window.auto === "on"){window.startCountdown(120);}
        // 1) Đang ở terravilla + auto ON → chạy tới portal + chọn land
        if (mapid === "terravilla" && window.auto === "on") {
            const room = window.pga.helpers.getRoomScene();
            room.movementPointer = randomPointInArea();

            await delay(2000);
            await waitUntilStop(); // đợi nhân vật dừng

            click_port();

            const landid = await window.getMatchingFarms();
            if (landid && landid[0]?.landName) {
                window.setInputValue(
                    landid[0].landName.replace("pixelsNFTFarm-", "")
                );
            }
        }

        // 2) Đang ở shareInter* + auto ON → replay path → moveAll → televilla
        if (mapid.startsWith("shareInter") && window.auto === "on" && mapid !== "pixelsNFTFarm-2218" ) {
            const path = window.player_position?.[mapid];
            if (path && path.length) {
                await window.replayPath(path);   // 🔹 nhớ await
            }

            await delay(2000);
            await waitUntilStop();
            await window.moveAll();
            await window.televilla();
        }
        if(mapid === "pixelsNFTFarm-2218"  && window.auto === "on" ){
            await delay(2000);
            window.click_ent("ent_saunaportal")
        }
        if(mapid === "SaunaInterior"  && window.auto === "on" ){
            await delay(2000);
            await   window.replayPath(window.player_position[window.pga?.gameState?.mapId])
            await window.click_ent("ent_saunarocks_charger");
            await window.televilla();
        }
    });
    function click_port(){
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room?.entities) return [];

        const list = [...room.entities.values()];

        const portals = list.filter(e => {
            const id = e?.gameEntity?.id?.toLowerCase() || "";
            return id === "ent_infiniportal";
        });

        portals[0].clicked(window.makePointerForEntity(portals[0]), {})

    }
    function randomPointInArea() {
        const p1 = { x: 2856.078413312925, y: 3133.6917332141047 }
        const p2 = { x: 3027.086939058292, y: 3218.0739985065507 }

        const minX = Math.min(p1.x, p2.x);
        const maxX = Math.max(p1.x, p2.x);

        const minY = Math.min(p1.y, p2.y);
        const maxY = Math.max(p1.y, p2.y);

        const x = Math.random() * (maxX - minX) + minX;
        const y = Math.random() * (maxY - minY) + minY;

        return { x, y };
    }
    function waitUntilStop(maxTime = 20000, interval = 50) {
        return new Promise(resolve => {
            const start = Date.now();

            const timer = setInterval(() => {
                const self = window.pga?.helpers?.getRoomScene?.()?.selfPlayer;

                // nếu không tìm thấy selfPlayer => trả về luôn
                if (!self) {
                    clearInterval(timer);
                    return resolve(false);
                }

                // nhân vật đã dừng
                if (!self.isMoving) {
                    clearInterval(timer);
                    return resolve(true);
                }

                // quá thời gian tối đa
                if (Date.now() - start > maxTime) {
                    clearInterval(timer);
                    return resolve(false);
                }

            }, interval);
        });
    }

})();