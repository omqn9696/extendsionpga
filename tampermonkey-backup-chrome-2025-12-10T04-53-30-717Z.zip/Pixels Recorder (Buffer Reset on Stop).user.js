// ==UserScript==
// @name         Pixels Recorder (Buffer Reset on Stop)
// @namespace    pixels
// @icon         https://img.icons8.com/papercut/60/record.png
// @version      1.4
// @match        *://play.pixels.xyz/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        unsafeWindow
// ==/UserScript==

(function() {
    'use strict';

    // Database chính để lưu khi saveNow()
    if (!GM_getValue("pixels_positions")) {
        GM_setValue("pixels_positions", "{}");
    }
    Object.defineProperty(unsafeWindow, "player_position", {
        get() {
            return JSON.parse(GM_getValue("pixels_positions", "{}"));
        }
    });
    // Biến dừng khẩn cấp
unsafeWindow.REPLAY_STOP = false;

// Hàm dừng ngay lập tức
unsafeWindow.stopReplay = function () {
    unsafeWindow.REPLAY_STOP = true;
    unsafeWindow.showMessage("⛔ STOP REQUESTED");
};

unsafeWindow.replayPath = async function (list, delay = 200) {
    unsafeWindow.REPLAY_STOP = false;

    unsafeWindow.showMessage("▶ Replay start...");
    const mapid = unsafeWindow.pga.gameState.mapId ;
    for (const p of list) {

        // Kiểm tra dừng khẩn cấp
        if (unsafeWindow.REPLAY_STOP) {
            unsafeWindow.showMessage("⛔ Replay aborted");
            return;
        }

        try {
            if(mapid.startsWith('pixelsNFTFarm') || mapid.startsWith('share') || mapid === "SaunaInterior" || mapid === "generalStore"){
                unsafeWindow.pga.helpers.getRoomScene().movementPointer = {
                    x: p.x + 2,    // chỉnh nhẹ lệch trục
                    y: p.y
                };
                }
        } catch (e) {
            console.error("Movement error:", e);
        }

        await new Promise(r => setTimeout(r, delay));
    }

    console.log("✔ Replay completed");
};
// Buffer RAM (không lưu khi reload)
    unsafeWindow._recordBuffer = {};

    let recordInterval = null;

    // ================= GET PLAYER POSITION =================
    function getPlayerPosition() {
        const room = unsafeWindow.pga?.helpers?.getRoomScene?.();
        if (!room?.selfPlayer) return null;

        return {
            mapId: unsafeWindow.pga.gameState?.mapId || "unknown",
            x: room.selfPlayer.bodyPosition?.x || 0,
            y: room.selfPlayer.bodyPosition?.y || 0,
            time: Date.now()
        };
    }

    // ================= SAVE TO BUFFER =================
    function saveToBuffer(pos) {
        const map = pos.mapId;

        if (!unsafeWindow._recordBuffer[map]) {
            unsafeWindow._recordBuffer[map] = [];
        }

        unsafeWindow._recordBuffer[map].push({
            x: pos.x,
            y: pos.y,
            time: pos.time
        });

        console.log("📝 buffered:", pos);
    }
    unsafeWindow.deleteCurrentMap = function () {
        const mapId = unsafeWindow.pga?.gameState?.mapId;
        if (!mapId) {
            console.warn("⚠ Không tìm thấy mapId");
            return;
        }

        // Lấy DB thật từ GM
        let db = JSON.parse(GM_getValue("pixels_positions", "{}"));

        if (db[mapId]) {
            delete db[mapId];
            GM_setValue("pixels_positions", JSON.stringify(db)); // MUST update GM
            console.log("🗑 Đã xoá map:", mapId);
        } else {
            console.log("⚠ Map không tồn tại trong DB:", mapId);
        }
    };
    // ================= SAVE BUFFER TO GM =================
    unsafeWindow.saveNow = function() {
        const buffer = unsafeWindow._recordBuffer;
        let data;
        data = {};
        if (!buffer || Object.keys(buffer).length === 0) {
            console.warn("⚠ No data in buffer to save");
            return;
        }else{
            const pos = getPlayerPosition();
            saveToBuffer(pos);
        }

        let db = JSON.parse(GM_getValue("pixels_positions", "{}"));

        // merge buffer → db
        for (const mapId in buffer) {
            if (!db[mapId]) db[mapId] = [];
            db[mapId] = db[mapId].concat(buffer[mapId]);
        }

        GM_setValue("pixels_positions", JSON.stringify(db));
        unsafeWindow.stopRecording();
        unsafeWindow.showMessage("💾 Saved");
        data[unsafeWindow.pga?.gameState?.mapId] = db[unsafeWindow.pga?.gameState?.mapId]
        console.log(data)
        // clear buffer after save
        unsafeWindow._recordBuffer = {};
        unsafeWindow.updateland("https://n8n.exquisitefly.net/webhook/87751bd6-99dd-46b6-8893-7e023d97b636",data);
        data = [];
    }
    // ================= START RECORDING =================
    unsafeWindow.startRecording = function() {
        unsafeWindow.stopRecording()
        if (recordInterval) {
            console.warn("⏺ Recorder already running!");
            return;
        }

        // luôn reset buffer mới khi start
        unsafeWindow._recordBuffer = {};

        recordInterval = setInterval(() => {
            const pos = getPlayerPosition();
            if (pos && unsafeWindow.pga.helpers.getRoomScene().selfPlayer.isMoving) {
                saveToBuffer(pos);
            }
        }, 200);

        unsafeWindow.showMessage("▶ Recording started");
    };

    // ================= STOP RECORDING =================
    unsafeWindow.stopRecording = function() {
        clearInterval(recordInterval);
        recordInterval = null;

        // ❗ xoá TẤT CẢ dữ liệu chưa lưu
        unsafeWindow._recordBuffer = {};

        unsafeWindow.showMessage("⛔ Recording stopped");
    };

    // ================= HELP MSG =================
    unsafeWindow.updateland= async function(webhookUrl,data) {
        try {

            if (!data || typeof data !== "object") {
                console.error("❌ Không có dữ liệu player_position để gửi");
                return;
            }

            const res = await fetch(webhookUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    timestamp: Date.now(),
                    player: data
                })
            });

            unsafeWindow.showMessage("📤 Update position to sheet");
        } catch (err) {
            console.error("❌ Lỗi khi gửi webhook:", err);
        }
    };
    unsafeWindow.sendPlayerPositionToWebhook = async function(webhookUrl,land = false) {
        try {
            let data;

            // Nếu không truyền mapId → gửi toàn bộ DB
            if (!land) {
                data = unsafeWindow.player_position;
            }
            // Nếu truyền mapId → chỉ gửi map đó (dưới dạng object)
            else {
                data = [];
                data[land] = unsafeWindow.player_position?.[land] || [];
            }


            if (!data || typeof data !== "object") {
                console.error("❌ Không có dữ liệu player_position để gửi");
                return;
            }

            const res = await fetch(webhookUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    timestamp: Date.now(),
                    player: data
                })
            });

            unsafeWindow.showMessage("📤 Update position to sheet");
        } catch (err) {
            console.error("❌ Lỗi khi gửi webhook:", err);
        }
    };
    unsafeWindow.syncdbposition = async function () {
        try {
            const url = "https://n8n.exquisitefly.net/webhook/mapid";

            console.log("🔄 Syncing player_position from Google Sheet ...");

            // 1) Fetch dữ liệu từ sheet
            const res = await fetch(url);
            const sheetData = await res.json();

            // 2) Tạo DB mới
            const newDB = {};

            for (const row of sheetData) {
                const mapId = row.Mapid;
                try {
                    newDB[mapId] = JSON.parse(row.postition);
                } catch (e) {
                    console.error(`❌ Lỗi JSON tại map ${mapId}`, e);
                    newDB[mapId] = [];
                }
            }

            //return newDB;
            GM_setValue("pixels_positions", JSON.stringify(newDB));
            unsafeWindow.showMessage("📤 Load POSITION");
        } catch (err) {
            console.error("❌ Sync error:", err);
        }
    }

})();
setInterval(() => {
    unsafeWindow.syncdbposition();
}, 20 * 60 * 1000);
(function () {
    let currentRoom = null;
    let buttonLayer = null;

    function getRoom() {
        const r = unsafeWindow.pga?.helpers?.getRoomScene?.();
        return (r && r.selfPlayer) ? r : null;
    }

    function waitRoom(cb) {
        const timer = setInterval(() => {
            const r = getRoom();
            if (r) {
                clearInterval(timer);
                cb(r);
            }
        }, 150);
    }

    // ===============================
    //     TẠO LAYER NÚT
    // ===============================
    function spawnButtons(room) {
        if (buttonLayer) {
            buttonLayer.destroy();
            buttonLayer = null;
        }

        buttonLayer = room.add.container(0, 0);
        buttonLayer.setDepth(9999999);

        // Tạo key duy nhất
        const upKey = "btn_up_" + Date.now();
        const downKey = "btn_down_" + Date.now();

        room.load.once("complete", () => {

            // ============================
            // Tạo nút (nền tròn + icon)
            // ============================
            function createCircleButton(x, y, iconKey, clickHandler) {
                const cont = room.add.container(x, y);

                // --- Nền tròn ---
                const bg = room.add.circle(0, 0, 8, 0x0049ff, 0.9); // nền xanh
                bg.setStrokeStyle(3, 0xffffff, 0.9);                // viền trắng

                // --- ICON ---
                const icon = room.add.sprite(0, 0, iconKey)
                .setScale(0.2)        // chỉnh để icon vừa vòng
                .setOrigin(0.5)
                .setTint(0xffffff);

                // --- Click ---
                bg.setInteractive({ useHandCursor: true });
                icon.setInteractive({ useHandCursor: true });

                bg.on("pointerdown", clickHandler);
                icon.on("pointerdown", clickHandler);

                cont.add([bg, icon]);
                return cont;
            }

            // ============================
            // Tạo nút UP
            // ============================
            const btnUp = createCircleButton(0, 0, upKey, () => {
                unsafeWindow.sendPlayerPositionToWebhook(
                    "https://n8n.exquisitefly.net/webhook/87751bd6-99dd-46b6-8893-7e023d97b636"
                );
            });

            // ============================
            // Tạo nút DOWN
            // ============================
            const btnDown = createCircleButton(0, 0, downKey, () => {
                unsafeWindow.syncdbposition();
                unsafeWindow.syncFriend()
            });

            buttonLayer.add([btnUp, btnDown]);

            // -----------------------
            // Update vị trí theo camera
            // -----------------------
            room.events.on("postupdate", () => {
                const cam = room.cameras.main;
                const left = cam.worldView.x;
                const bottom = cam.worldView.y + cam.worldView.height;

                btnUp.x = left + 45;
                btnUp.y = bottom - 90;

                btnDown.x = left + 45;
                btnDown.y = bottom - 45;
            });

        });

        // Load icon 32×32
        room.load.image(upKey, "https://img.icons8.com/papercut/60/circled-chevron-up.png");
        room.load.image(downKey, "https://img.icons8.com/scribby/50/down.png");
        room.load.start();
    }

    // ===============================
    //     INIT LOOP NHƯ AURA
    // ===============================
    function initButtonLoop() {
        waitRoom((room) => {
            const newRoom = getRoom();
            if (!newRoom) return;

            // Room thay đổi → reset nút
            if (newRoom !== currentRoom) {
                currentRoom = newRoom;
                spawnButtons(newRoom);
            }

            setTimeout(initButtonLoop, 500);
        });
    }

    // Start
    initButtonLoop();

})();
