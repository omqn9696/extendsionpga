// ==UserScript==
// @name         Keyboard Events
// @namespace    pixels
// @icon         https://img.icons8.com/external-xnimrodx-lineal-xnimrodx/64/external-keyboard-design-tools-xnimrodx-lineal-xnimrodx.png
// @version      1.2
// @description  Nơi các sự kiện đăng ký xử lý bàn phím
// @author       Drayke
// @match        *://play.pixels.xyz/*
// @grant        none
// ==/UserScript==

(function () {
    const makePointerForEntity = window.makePointerForEntity;
    function rank_web() {
        if (document.getElementById("multiIframePopup")) return;

        // ====== STYLE ======
        const css = `
    #multiIframePopup {
        position: fixed;
        top: 40px;
        right: 40px;
        width: 90%;
        height: 80vh;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0,0,0,0.25);
        z-index: 999999;
        overflow: hidden;
        display: flex;
        flex-direction: column;
    }

    #mip_header {
        background: #292929;
        color: #fff;
        padding: 10px;
        display: flex;
        gap: 5px;
    }

    #mip_header button {
        flex: 1;
        padding: 8px;
        background: #444;
        color: #fff;
        border: none;
        cursor: pointer;
        border-radius: 4px;
        font-size: 14px;
    }

    #mip_header button.active {
        background: #0aa0ff;
    }

    #mip_close {
        background: red !important;
        max-width: 40px;
    }

    .mip_frame {
        flex: 1;
        width: 100%;
        height: 100%;
        border: none;
        display: none;
    }

    .mip_frame.active {
        display: block;
    }
    `;

        const style = document.createElement("style");
        style.textContent = css;
        document.head.appendChild(style);

        // ====== POPUP HTML ======
        const wrapper = document.createElement("div");
        wrapper.id = "multiIframePopup";

        wrapper.innerHTML = `
        <div id="mip_header">
            <button data-frame="1" class="active">Reapers</button>
            <button data-frame="2">Wildgroves</button>
            <button data-frame="3">Seedwrights</button>
            <button id="mip_close">X</button>
        </div>

        <iframe id="mip_frame_1" class="mip_frame active" src="https://dashboard.pixels.xyz/leaderboards/ldb_unionScore_reapers"></iframe>
        <iframe id="mip_frame_2" class="mip_frame" src="https://dashboard.pixels.xyz/leaderboards/ldb_unionScore_wildgroves"></iframe>
        <iframe id="mip_frame_3" class="mip_frame" src="https://dashboard.pixels.xyz/leaderboards/ldb_unionScore_seedwrights"></iframe>
    `;

        document.body.appendChild(wrapper);

        // ====== JS CONTROL ======
        const tabs = wrapper.querySelectorAll("#mip_header button[data-frame]");
        const frames = wrapper.querySelectorAll(".mip_frame");

        tabs.forEach(btn => {
            btn.onclick = () => {
                const id = btn.dataset.frame;

                tabs.forEach(t => t.classList.remove("active"));
                frames.forEach(f => f.classList.remove("active"));

                btn.classList.add("active");
                document.getElementById("mip_frame_" + id).classList.add("active");
            };
        });

        document.getElementById("mip_close").onclick = () => wrapper.remove();
    }
    function clearScene() {
        const entityWhitelist = ['ent_mine_04', 'ent_roadtv', 'ent_rightroad', 'ent_leftroad', 'ent_pineappleMulet','ent_infiniportal'];
        const entityPrefixWhitelist = ['ent_metalworking', 'ent_woo','ent_kiln','ent_all','ent_tree','ent_crop'];

        window.pga.helpers.getRoomScene().entities.forEach(entity => {
            const id = entity?.gameEntity?.id;

            if (!id) {
                entity.destroy();
                return;
            }

            // ✅ fix thiếu dấu || ở đây
            const isWhitelisted =
                  entityWhitelist.includes(id) ||
                  entityPrefixWhitelist.some(prefix => id.startsWith(prefix));

            if (!isWhitelisted) {
                entity.destroy();
            }
        });

        // Xử lý gameObjects
        const objectWhitelist = ['obj_astra', 'obj_wall'];
        Object.values(window.pga.helpers.getRoomScene().gameObjects).forEach(obj => {
            if (!objectWhitelist.some(prefix => obj.propCache?.element?.startsWith(prefix))) {
                obj.destroy();
            }
        });
    }
    function goToVilla() {
        window.stopRecording()
        const targets = document.querySelectorAll(".Hud_outside__zzIGQ");
        for (const el of targets) {
            const img = el.querySelector('img[aria-label="Land and Bookmarks"]');
            if (!img) continue;

            el.click();
            setTimeout(() => {
                const btnContainer = document.querySelector(".LandAndTravel_customHeader__goUPo");
                const btn = btnContainer && [...btnContainer.querySelectorAll("button")]
                .find(b => b.textContent.trim() === "Go to Terra Villa");
                btn?.click();
            }, 1000);
            break;
        }
    }

    function goToSpeck() {
        const targets = document.querySelectorAll(".Hud_outside__zzIGQ");
        for (const el of targets) {
            const img = el.querySelector('img[aria-label="Land and Bookmarks"]');
            if (!img) continue;

            // mở popup Land & Travel
            el.click();

            setTimeout(() => {
                const btnContainer = document.querySelector(".LandAndTravel_customHeader__goUPo");
                if (!btnContainer) return;

                // tìm ô "My Speck" trong danh sách
                const items = document.querySelectorAll('.LandAndTravel_mapSquare__LuVEh.clickable');
                for (const item of items) {
                    const label = item.querySelector('.LandAndTravel_mapText__hEuVl');
                    if (label && label.textContent.trim() === 'My Speck') {
                        item.click();
                        break;
                    }
                }
            }, 1000);

            break;
        }
    }

    /*********** 🧭 AUTO COLLECT ***********/
    async function collectReadyStations() {
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room?.entities) return;

        const ready = [...room.entities.values()].filter(e => {
            if (!e) return false;
            const id = e?.gameEntity?.id || "";
            return (
                (e.state === "ready"  || e.state === "wood" || e.state === "default") &&
                !id.toLowerCase().includes("portal")
            );
        });

        for (const ent of ready) {
            ent.clicked(makePointerForEntity(ent), {});
            await new Promise(r => setTimeout(r, 150 + Math.random() * 80));
        }
    }
    function toggleTiger() {
        window.mine_tiger = (window.mine_tiger === 3 ? 4 : 3);
        const btn = document.querySelector('.profitPerEnergyToggle');
        if (btn) {
            btn.src = (window.mine_tiger === 3)
                ? 'https://assets.pixels.tips/images/icons/land-water.webp'
            : 'https://assets.pixels.tips/images/icons/land-space.webp';
        }
    }
    function toggleauto() {
        window.auto = (window.auto === 'off' ? 'on' : 'off');
        const btn = document.querySelector('.automation');
        if (btn) {
            btn.src = (window.auto === 'off')
                ? 'https://guildpal.com/images/pga/toggle-off.png'
            : 'https://guildpal.com/images/pga/toggle-on.png';
        }
    }

    document.addEventListener('keydown', function (e) {
        const key = e.key.toLowerCase();

        switch (true) {
            case (e.code === 'Space'): {
                e.preventDefault();
                clearScene();
                const scene = window.pga.helpers.getRoomScene();
                scene.stateManager.players.get(scene.playerId).memberships["guild-member-guildpal"] = {
                    count: 1,
                    role: "Supporter"
                };
                break;
            }

            case (e.key === "Home"):
                goToVilla();
                break;
            case (key === "shift"):
                window.saveNow();
                break;
            case (key === "delete"):
                window.stopReplay()
                window.deleteCurrentMap();
                break;
            case (key === "backspace"):
                window.startRecording();
                break;
            case (e.key === "End"):
                goToSpeck();
                break;

            case (key === "q"):
                toggleTiger();
                break;
            case (key === "m"):
              window.stopReplay()
                break;
            case (key === "e"):
                rank_web()
                break;
            case (key === "x"):
                mod_skin(pga.helpers.getRoomScene().hoverNode.playerData.avatar)
                break;
            case (key === "pagedown"):
                collectReadyStations();
                break;

            case (e.code === "AudioVolumeMute"):
                goToSpeck();
                break;
            case (key === "v"):
                if (!window.vHoldTimer) {
                    window.vHoldTimer = setTimeout(() => {
                        if (window.vFrameContainer) return;

                        const wrap = document.createElement("div");
                        wrap.style.cssText = `
                        position: fixed;
                        inset: 0;
                        background: rgba(0,0,0,0.6);
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        z-index: 99999;
                    `;

                        const iframe = document.createElement("iframe");
                        iframe.src = "https://htmlpreview.github.io/?https://raw.githubusercontent.com/omqn9696/extendsionpga/refs/heads/main/lv.html";
                        iframe.style.cssText = `
                        width: 80%;
                        height: 80%;
                        border: 2px solid #fff;
                        border-radius: 8px;
                        background: #fff;
                        box-shadow: 0 0 20px rgba(0,0,0,0.4);
                    `;

                        const closeBtn = document.createElement("button");
                        closeBtn.textContent = "✖";
                        closeBtn.style.cssText = `
                        position: absolute;
                        top: 20px;
                        right: 30px;
                        background: #000;
                        color: #fff;
                        border: none;
                        border-radius: 50%;
                        width: 36px;
                        height: 36px;
                        font-size: 18px;
                        cursor: pointer;
                    `;
                        closeBtn.addEventListener("click", () => {
                            wrap.remove();
                            window.vFrameContainer = null;
                        });

                        wrap.appendChild(iframe);
                        wrap.appendChild(closeBtn);
                        document.body.appendChild(wrap);
                        window.vFrameContainer = wrap;
                    }, 500);
                }
                break;
        }
    });

    // Khi thả phím ra thì huỷ timer nếu chưa tạo iframe
    document.addEventListener("keyup", (e) => {
        if (e.key.toLowerCase() === "v") {
            clearTimeout(window.vHoldTimer);
            window.vHoldTimer = null;
        }
    });
    function mod_skin(avatar){
        if(!avatar) return
        const a =  window.pga.helpers.getRoomScene().selfPlayer.playerData;
        a.avatar = avatar
        a.position = {
            x: window.pga.helpers.getRoomScene().selfPlayer.previousPosition.x || window.pga.helpers.getRoomScene().selfPlayer.characterHelper.characterData.position.x,
            y: window.pga.helpers.getRoomScene().selfPlayer.previousPosition.y || window.pga.helpers.getRoomScene().selfPlayer.characterHelper.characterData.position.y
        };
        const pet = window.pga.helpers.getRoomScene().selfPlayer.petData ;
        if(pet){
            pet.avatar ={
                "id": "pixelspets",
                "kind": "pet",
                "enabled": true,
                "animations": {
                    "idle": {
                        "animation": "idle",
                        "start": 0,
                        "end": 3,
                        "frameRate": 4,
                        "repeat": -1
                    },
                    "walk": {
                        "animation": "walk",
                        "start": 4,
                        "end": 9,
                        "frameRate": 6,
                        "repeat": -1
                    },
                    "run": {
                        "animation": "run",
                        "start": 10,
                        "end": 14,
                        "frameRate": 5,
                        "repeat": -1
                    },
                    "jump": {
                        "animation": "jump",
                        "start": 15,
                        "end": 16,
                        "frameRate": 5,
                        "repeat": -1
                    },
                    "sit": {
                        "animation": "sit",
                        "start": 17,
                        "end": 17,
                        "frameRate": 5,
                        "repeat": -1
                    }
                },
                "physics": {
                    "enabled": true,
                    "size": {
                        "height": 5,
                        "width": 18
                    },
                    "offset": {
                        "x": 0,
                        "y": 18
                    }
                },
                "sprite": {
                    "isSpritesheet": true,
                    "scale": 1,
                    "frames": 18,
                    "size": {
                        "height": 39,
                        "width": 53
                    }
                },
                "pieces": [
                    {
                        "attributes": [
                            {
                                "default": "land",
                                "id": "terrain",
                                "name": "terrain"
                            }
                        ],
                        "background": true,
                        "id": "terrain",
                        "url": {
                            "override": [
                                {
                                    "text": "/background/"
                                },
                                {
                                    "attribute": "terrain"
                                },
                                {
                                    "text": ".png"
                                }
                            ]
                        }
                    },
                    {
                        "attributes": [
                            {
                                "default": "none",
                                "id": "tailcolor",
                                "name": "tailcolor"
                            }
                        ],
                        "id": "tail",
                        "url": {
                            "override": [
                                {
                                    "text": "/tail/"
                                },
                                {
                                    "attribute": "tail"
                                },
                                {
                                    "text": "/"
                                },
                                {
                                    "attribute": "tailcolor"
                                },
                                {
                                    "text": ".png"
                                }
                            ]
                        }
                    },
                    {
                        "attributes": [],
                        "id": "body",
                        "url": {
                            "override": [
                                {
                                    "text": "/body/"
                                },
                                {
                                    "attribute": "body"
                                },
                                {
                                    "text": "/"
                                },
                                {
                                    "attribute": "bodycolor"
                                },
                                {
                                    "text": ".png"
                                }
                            ]
                        }
                    },
                    {
                        "attributes": [],
                        "id": "head",
                        "url": {
                            "override": [
                                {
                                    "text": "/head/"
                                },
                                {
                                    "attribute": "head"
                                },
                                {
                                    "text": "/"
                                },
                                {
                                    "attribute": "headcolor"
                                },
                                {
                                    "text": ".png"
                                }
                            ]
                        }
                    },
                    {
                        "attributes": [],
                        "id": "eyes",
                        "url": {
                            "override": [
                                {
                                    "text": "/eyes/"
                                },
                                {
                                    "attribute": "eyes"
                                },
                                {
                                    "text": "/"
                                },
                                {
                                    "attribute": "eyecolor"
                                },
                                {
                                    "text": ".png"
                                }
                            ]
                        }
                    },
                    {
                        "attributes": [],
                        "id": "mouth",
                        "url": {
                            "override": [
                                {
                                    "text": "/head/"
                                },
                                {
                                    "attribute": "head"
                                },
                                {
                                    "text": "/mouth/"
                                },
                                {
                                    "attribute": "mouth"
                                },
                                {
                                    "text": ".png"
                                }
                            ]
                        }
                    },
                    {
                        "attributes": [
                            {
                                "default": "none",
                                "id": "adornmentcolor",
                                "name": "adornmentcolor"
                            }
                        ],
                        "id": "adornment",
                        "url": {
                            "override": [
                                {
                                    "text": "/adornment/"
                                },
                                {
                                    "attribute": "adornment"
                                },
                                {
                                    "text": "/"
                                },
                                {
                                    "attribute": "adornmentcolor"
                                },
                                {
                                    "text": ".png"
                                }
                            ]
                        }
                    }
                ],
                "defaults": [],
                "chain": "ronin",
                "contractAddress": "0xb806028b6ebc35926442770a8a8a7aeab6e2ce5c",
                "defaultAvatar": {
                    "body": "none"
                },
                "mood": 1,
                "display": {
                    "nft": true,
                    "edition": "halloweenbats2025",
                    "luck": 30,
                    "speed": 100,
                    "strength": 30,
                    "smarts": 30,
                    "terrain": "land",
                    "head": "batsy",
                    "body": "bat",
                    "eyecolor": "icy",
                    "eyes": "batloony",
                    "bodycolor": "pinky",
                    "headcolor": "pinky"
                }
            }
        }else{
            const pet = {
                "avatar": {
                    "id": "pixelspets",
                    "kind": "pet",
                    "enabled": true,
                    "animations": {
                        "idle": {
                            "animation": "idle",
                            "start": 0,
                            "end": 3,
                            "frameRate": 4,
                            "repeat": -1
                        },
                        "walk": {
                            "animation": "walk",
                            "start": 4,
                            "end": 9,
                            "frameRate": 6,
                            "repeat": -1
                        },
                        "run": {
                            "animation": "run",
                            "start": 10,
                            "end": 14,
                            "frameRate": 5,
                            "repeat": -1
                        },
                        "jump": {
                            "animation": "jump",
                            "start": 15,
                            "end": 16,
                            "frameRate": 5,
                            "repeat": -1
                        },
                        "sit": {
                            "animation": "sit",
                            "start": 17,
                            "end": 17,
                            "frameRate": 5,
                            "repeat": -1
                        }
                    },
                    "physics": {
                        "enabled": true,
                        "size": {
                            "height": 5,
                            "width": 18
                        },
                        "offset": {
                            "x": 0,
                            "y": 18
                        }
                    },
                    "sprite": {
                        "isSpritesheet": true,
                        "scale": 1,
                        "frames": 18,
                        "size": {
                            "height": 39,
                            "width": 53
                        }
                    },
                    "pieces": [
                        {
                            "attributes": [
                                {
                                    "default": "land",
                                    "id": "terrain",
                                    "name": "terrain"
                                }
                            ],
                            "background": true,
                            "id": "terrain",
                            "url": {
                                "override": [
                                    {
                                        "text": "/background/"
                                    },
                                    {
                                        "attribute": "terrain"
                                    },
                                    {
                                        "text": ".png"
                                    }
                                ]
                            }
                        },
                        {
                            "attributes": [
                                {
                                    "default": "none",
                                    "id": "tailcolor",
                                    "name": "tailcolor"
                                }
                            ],
                            "id": "tail",
                            "url": {
                                "override": [
                                    {
                                        "text": "/tail/"
                                    },
                                    {
                                        "attribute": "tail"
                                    },
                                    {
                                        "text": "/"
                                    },
                                    {
                                        "attribute": "tailcolor"
                                    },
                                    {
                                        "text": ".png"
                                    }
                                ]
                            }
                        },
                        {
                            "attributes": [],
                            "id": "body",
                            "url": {
                                "override": [
                                    {
                                        "text": "/body/"
                                    },
                                    {
                                        "attribute": "body"
                                    },
                                    {
                                        "text": "/"
                                    },
                                    {
                                        "attribute": "bodycolor"
                                    },
                                    {
                                        "text": ".png"
                                    }
                                ]
                            }
                        },
                        {
                            "attributes": [],
                            "id": "head",
                            "url": {
                                "override": [
                                    {
                                        "text": "/head/"
                                    },
                                    {
                                        "attribute": "head"
                                    },
                                    {
                                        "text": "/"
                                    },
                                    {
                                        "attribute": "headcolor"
                                    },
                                    {
                                        "text": ".png"
                                    }
                                ]
                            }
                        },
                        {
                            "attributes": [],
                            "id": "eyes",
                            "url": {
                                "override": [
                                    {
                                        "text": "/eyes/"
                                    },
                                    {
                                        "attribute": "eyes"
                                    },
                                    {
                                        "text": "/"
                                    },
                                    {
                                        "attribute": "eyecolor"
                                    },
                                    {
                                        "text": ".png"
                                    }
                                ]
                            }
                        },
                        {
                            "attributes": [],
                            "id": "mouth",
                            "url": {
                                "override": [
                                    {
                                        "text": "/head/"
                                    },
                                    {
                                        "attribute": "head"
                                    },
                                    {
                                        "text": "/mouth/"
                                    },
                                    {
                                        "attribute": "mouth"
                                    },
                                    {
                                        "text": ".png"
                                    }
                                ]
                            }
                        },
                        {
                            "attributes": [
                                {
                                    "default": "none",
                                    "id": "adornmentcolor",
                                    "name": "adornmentcolor"
                                }
                            ],
                            "id": "adornment",
                            "url": {
                                "override": [
                                    {
                                        "text": "/adornment/"
                                    },
                                    {
                                        "attribute": "adornment"
                                    },
                                    {
                                        "text": "/"
                                    },
                                    {
                                        "attribute": "adornmentcolor"
                                    },
                                    {
                                        "text": ".png"
                                    }
                                ]
                            }
                        }
                    ],
                    "defaults": [],
                    "chain": "ronin",
                    "contractAddress": "0xb806028b6ebc35926442770a8a8a7aeab6e2ce5c",
                    "defaultAvatar": {
                        "body": "none"
                    },
                    "mood": 1,
                    "display": {
                        "nft": true,
                        "edition": "halloweenbats2025",
                        "luck": 30,
                        "speed": 100,
                        "strength": 30,
                        "smarts": 30,
                        "terrain": "land",
                        "head": "batsy",
                        "body": "bat",
                        "eyecolor": "icy",
                        "eyes": "batloony",
                        "bodycolor": "pinky",
                        "headcolor": "pinky"
                    }
                },
                "position": {
                    "x": a.position.x,
                    "y": a.position.y
                },
                "label": "Girl BEO",
                "kind": "pet"
            }
            }
        window.pga.helpers.getRoomScene().selfPlayer.updatePetData(pet);
        let e = (a);
        delete e.kind,
            window.pga.helpers.getRoomScene().selfPlayer.updatePlayerData((a)),
            window.pga.helpers.getRoomScene().removeNode( window.pga.helpers.getRoomScene().selfPlayer),
            window.pga.helpers.getRoomScene().nodesToAdd.push(window.pga.helpers.getRoomScene().selfPlayer)
        return  a.avatar;
    }
    function makeDraggable(el, storageKey, onClick) {
        let isDragging = false;
        let moved = false;
        let offsetX = 0, offsetY = 0;

        // Load vị trí đã lưu
        const saved = localStorage.getItem(storageKey);
        if (saved) {
            const { top, left } = JSON.parse(saved);
            el.style.top = top;
            el.style.left = left;
            el.style.right = "auto";
        }

        el.addEventListener("mousedown", (e) => {
            isDragging = true;
            moved = false;
            offsetX = e.clientX - el.offsetLeft;
            offsetY = e.clientY - el.offsetTop;
            el.style.transition = "none";
            el.style.cursor = "grabbing";
        });

        document.addEventListener("mousemove", (e) => {
            if (!isDragging) return;
            moved = true;

            let newLeft = e.clientX - offsetX;
            let newTop = e.clientY - offsetY;

            // Giới hạn trong màn hình
            const maxLeft = window.innerWidth - el.offsetWidth;
            const maxTop = window.innerHeight - el.offsetHeight;

            if (newLeft < 0) newLeft = 0;
            if (newTop < 0) newTop = 0;
            if (newLeft > maxLeft) newLeft = maxLeft;
            if (newTop > maxTop) newTop = maxTop;

            el.style.left = newLeft + "px";
            el.style.top = newTop + "px";
            el.style.right = "auto";
        });

        document.addEventListener("mouseup", () => {
            if (!isDragging) return;
            isDragging = false;
            el.style.transition = "all 0.25s ease";
            el.style.cursor = "grab";

            // Lưu vị trí
            localStorage.setItem(storageKey, JSON.stringify({
                top: el.style.top,
                left: el.style.left
            }));
        });

        // Chỉ click khi không kéo
        el.addEventListener("click", (e) => {
            if (moved) {
                e.preventDefault();
                return;
            }
            onClick();
        });
    }

})();
