// ==UserScript==
// @name         cowndown
// @namespace    pixels
// @version      2.0
// @match        *://play.pixels.xyz/*
// @grant        none
// ==/UserScript==

(function () {
    let countdownTimer = null;
    let remaining = 0;

    window.startCountdown = function (seconds) {
        // nếu đang chạy → huỷ cái cũ
        if (countdownTimer) {
            clearInterval(countdownTimer);
            countdownTimer = null;
        }

        remaining = seconds;

        countdownTimer = setInterval(() => {

            // luôn truyền string
            window.showMessage(String(remaining), "pet");

            remaining--;

            // hết giờ
            if (remaining < 0) {
                clearInterval(countdownTimer);
                countdownTimer = null;

                if (typeof window.televilla === "function") {
                    window.televilla();
                }
            }

        }, 1000);
    };

    window.clearCountdown = function () {
        if (countdownTimer) {
            clearInterval(countdownTimer);
            countdownTimer = null;
        }
    };

})();

