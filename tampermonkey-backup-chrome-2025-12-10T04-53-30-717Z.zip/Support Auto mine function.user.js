// ==UserScript==
// @name         Support Auto mine function
// @namespace    pixels
// @version      1.1
// @description  các function automation s
// @author       Drayke
// @icon         https://img.icons8.com/external-filled-line-andi-nur-abdillah/64/external-Mine-mining-(filled-line)-filled-line-andi-nur-abdillah.png
// @match        *://play.pixels.xyz/*
// @grant        none
// ==/UserScript==

(function () {
    "use strict";
    window.stop_aoto_mine = stop_mine_cleart;

    let STOP_AUTOMINE = false

    const end_health = window.end_heath ;
    window.stop_all_auto = stop_auto;
    window.televilla = goToVilla;
    function stop_mine_cleart (){
        STOP_AUTOMINE = true;drawAutoStatus(false);
    }
    function goToVilla() {
        window.stopReplay(); window.stop_aoto_mine()
        window.depositE();
        const targets = document.querySelectorAll(".Hud_outside__zzIGQ");
        for (const el of targets) {
            const img = el.querySelector('img[aria-label="Land and Bookmarks"]');
            if (!img) continue;

            el.click();
            setTimeout(() => {
                const btnContainer = document.querySelector(".LandAndTravel_customHeader__goUPo");
                const btn = btnContainer && [...btnContainer.querySelectorAll("button")]
                .find(b => b.textContent.trim() === "Go to Terra Villa");
                btn?.click();
                window.speck_action = null
            }, 1000);
            break;
        }
    }
    async function collectReadyStations() {
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room?.entities) return;
        const allReady = [...room.entities.values()].filter(e => {
            if (!e) return false;
            const id = e?.gameEntity?.id?.toLowerCase() || "";
            return (
                (e.state === "ready" || e.state === "2egg") &&
                (id.includes("ent_mine_04") || id.includes("ent_coop") || id.includes("ent_sluggery"))
            );
        });
        const priority = allReady.filter(e => {
            const id = e?.gameEntity?.id?.toLowerCase() || "";
            return id.includes("ent_coop") || id.includes("ent_sluggery");
        });
        const others = allReady.filter(e => !priority.includes(e));
        let ready = [...priority, ...others];

        // 🚫 Loại bỏ entity trùng mid
        const seen = new Set();
        ready = ready.filter(e => {
            const mid = e?.mid || e?.gameEntity?.mid;
            if (!mid || seen.has(mid)) return false;
            seen.add(mid);
            return true;
        });

        // 🖱️ Click từng entity
        for (const ent of ready) {
            const id = ent?.gameEntity?.id || "";
            // console.log(`🐔 Collecting: ${id} (${ent.mid})`);
            try {
                ent.clicked(makePointerForEntity(ent), {});
                await new Promise(r => setTimeout(r, 150 + Math.random() * 80));
            } catch (err) {
                //console.warn(`⚠️ Lỗi khi click ${id}:`, err);
            }
        }
    }

    function waitForOnGameEvent(callback) {
        const check = setInterval(() => {
            if (typeof window.onGameEvent === "function") {
                clearInterval(check);
                callback();
            }
        }, 300);
    }
    function stop_auto(){
        if(!STOP_AUTO){
            STOP_AUTO = true
        }

    }
    function playBeep(type = "start") {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        // Chọn tần số & thời lượng theo loại
        let freq = 440, dur = 0.2;
        switch (type) {
            case "start": freq = 880; dur = 0.25; break;     // beep cao bắt đầu
            case "stop": freq = 200; dur = 0.4; break;       // beep trầm dừng
            case "done": freq = 600; dur = 0.3; break;       // beep trung khi hoàn tất
            case "error": freq = 120; dur = 0.5; break;      // lỗi
        }

        osc.type = "sine";
        osc.frequency.value = freq;
        osc.connect(gain);
        gain.connect(ctx.destination);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + dur);
    }
    function drawAutoStatus(isActive = true, text = "AUTO ") {
        let overlay = document.getElementById("autoStatusOverlay");

        // ❌ Nếu dừng → xóa và ngắt blink
        if (!isActive) {
            if (overlay) {
                clearInterval(overlay.blinkInterval);
                overlay.remove();
            }
            return;
        }

        // ✅ Nếu chưa tồn tại → tạo mới
        if (!overlay) {
            overlay = document.createElement("div");
            overlay.id = "autoStatusOverlay";
            Object.assign(overlay.style, {
                position: "fixed",
                bottom: "18px",
                left: "10%",
                transform: "translateX(-50%)",
                padding: "10px 22px",
                fontFamily: "monospace",
                fontSize: "15px",
                fontWeight: "700",
                letterSpacing: "1px",
                color: "#fff",
                textShadow: "0 0 8px rgba(0,255,140,0.8)",
                background: "red", // 🌑 nền xanh đậm bán trong suốt
                border: "1px solid rgba(0,255,150,0.7)",
                borderRadius: "12px",
                boxShadow: "0 0 20px rgba(0,255,140,0.25)",
                backdropFilter: "blur(5px)", // mờ nền phía sau
                zIndex: 99999,
                pointerEvents: "none",
                opacity: 0.95,
                transition: "opacity 0.3s ease",
            });
            document.body.appendChild(overlay);
        }

        // 🔠 Cập nhật nội dung
        overlay.innerHTML = `⛏️ ${text}`;

        // 🌟 Nhấp nháy nhẹ (hiệu ứng breathing)
        if (!overlay.blinkInterval) {
            overlay.blinkInterval = setInterval(() => {
                overlay.style.opacity = overlay.style.opacity === "0.5" ? "0.95" : "0.5";
            }, 800);
        }
    }
    /************ 🖱️ CLICK ENTITY ************/
    async function simulateEntityClick(entity) {
        try {
            const room = window.pga?.helpers?.getRoomScene?.();
            const cam = room?.cameras?.main;
            const canvas = document.querySelector("canvas");
            if (!canvas || !cam) return;

            const worldX = entity.x ?? 0, worldY = entity.y ?? 0;
            const ex = (worldX - cam.worldView.x) * cam.zoom;
            const ey = (worldY - cam.worldView.y) * cam.zoom;

            await moveHudTo(ex, ey, 18, 6);

            const pointer = {
                worldX,
                worldY,
                center: { x: worldX, y: worldY },
                position: { x: worldX, y: worldY },
                leftButtonReleased: () => true,
                leftButtonDown: () => false,
                rightButtonReleased: () => false,
                rightButtonDown: () => false,
                middleButtonReleased: () => false,
                middleButtonDown: () => false,
            };
            entity.clicked(pointer, {});
        } catch (err) {}
    }

    /************ 🌾 AUTO TRỒNG / TƯỚI / CẮT ************/
    let STOP_AUTO = false;
    window.makePointerForEntity = function(ent) {
        const room   = window.pga?.helpers?.getRoomScene?.();
        const canvas = window.pga?.drawing?.canvas;
        if (!room || !canvas || !ent?.position) return null;

        const cx = ent.position.x;
        const cy = ent.position.y;

        const w = ent.spriteW ?? 64;
        const h = ent.spriteH ?? 64;

        const rx = (Math.random() - 0.5) * w;
        const ry = (Math.random() - 0.5) * h;

        const worldX = cx + rx;
        const worldY = cy + ry;

        const scr = window.pga.helpers.getScreenCoords(
            room,
            worldX,
            worldY,
            1,
            1
        );
        if (!scr) return null;

        return {
            x: scr.x,
            y: scr.y,
            worldX,
            worldY,
            leftButtonReleased: () => true,
            rightButtonReleased: () => false,
            leftButtonDown: () => false,
            rightButtonDown: () => false,
        };
    };
    async function clickAllCropsSmart() {
        STOP_AUTO = false;

        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room?.entities) return showMessage("❌ Không tìm thấy room.entities");

        const entities = Array.from(room.entities.values());
        const redux = window.pga?.helpers?.getReduxValue?.()?.storage;
        const selectedItemId = redux?.selectedItem?.id;
        const selectedQty = redux?.selectedQty ?? 0;

        if (!selectedItemId) return showMessage("⚠️ Không có item nào đang được cầm!");
        if (selectedQty < 1) return showMessage("⚠️ Hết item để sử dụng!");

        let targetStates = [];
        let reverseMode = false;

        if (selectedItemId === "itm_rustyWateringCan") {
            targetStates = ["planted"];
            reverseMode = true; // 🔁 khi tưới, chạy ngược
        } else if (selectedItemId.endsWith("eeds")) targetStates = ["empty"];
        else if (selectedItemId.startsWith("itm_shears_")) targetStates = ["grown"];
        else return showMessage("⚠️ Item này không hợp lệ cho auto.");

        // 🌾 Lọc crop phù hợp
        const crops = entities.filter((ent) => {
            const id = ent?.gameEntity?.id;
            const s =
                  (ent?.state?.state ||
                   ent?.state ||
                   ent?.properties?.state ||
                   ent?.properties?.growthStage ||
                   ""
                  ).toString().toLowerCase();

            // ⚠️ Nếu đang tưới nước → chỉ lấy crop có utcTarget == 0
            if (selectedItemId === "itm_rustyWateringCan") {
                const target = ent?.currentState?.displayInfo?.utcTarget ?? 1;
                return id === "ent_allcrops" && targetStates.includes(s) && target === 0;
            }

            // các trường hợp còn lại (gieo hoặc cắt)
            return id === "ent_allcrops" && targetStates.includes(s);
        });

        if (!crops.length)
            return showMessage("✅ Không có ô ruộng phù hợp để click.");

        // 🧭 Gom nhóm crop theo hàng (theo y, làm tròn)
        const rows = {};
        for (const c of crops) {
            const y = Math.round(c.y / 10) * 10;
            if (!rows[y]) rows[y] = [];
            rows[y].push(c);
        }

        let sortedY = Object.keys(rows)
        .map(Number)
        .sort((a, b) => a - b);
        if (reverseMode) sortedY.reverse(); // 🔁 nếu watering → đi ngược hàng (dưới lên)

        showMessage(
            `🌾 Auto ${crops.length} ô | ${
            reverseMode ? "Reverse" : "Zigzag"
            } mode`
        );
        //console.log("⏳ Nhấn [S] để DỪNG KHẨN CẤP!");

        let reverse = false;
        for (const y of sortedY) {
            if (STOP_AUTO) return showMessage("🛑 Auto dừng khẩn cấp!");

            let row = rows[y];
            row.sort((a, b) => a.x - b.x);
            if (reverse) row.reverse();

            for (const crop of row) {
                if (STOP_AUTO) return showMessage("🛑 Auto dừng khẩn cấp!");

                // ⚠️ Kiểm tra tool health & energy
                const health =
                      window.pga?.helpers?.getReduxValue?.()?.storage?.selectedSlot?.state
                ?.displayInfo?.health ?? 999;
                const energy =
                      window.pga?.helpers?.getReduxValue?.()?.game?.player?.full?.energy
                ?.level ?? 999;

                if (health <= 0.5) {
                    STOP_AUTO = true;
                    return showMessage("🛑 Tool sắp hỏng! Dừng auto ngay!");
                }
                if (energy <= 4) {
                    STOP_AUTO = true;
                    return showMessage("🪫 Energy quá thấp (<4)! Dừng auto!");
                }

                const curQty =
                      window.pga?.helpers?.getReduxValue?.()?.storage?.selectedQty ?? 0;
                if (curQty < 1) {
                    showMessage("❌ Hết item giữa chừng — dừng auto.");
                    return;
                }

                await simulateEntityClick(crop);
                await new Promise((r) => setTimeout(r, 10 + Math.random() * 10)); // ⚡ 10–20ms
            }

            reverse = !reverse;
        }

        if (!STOP_AUTO) showMessage("✅ Hoàn tất auto!");

        function stopMsg(msg) {
            showMessage(msg);
            console.warn(msg);
        }
    }
    async function makePointerForEntity(entity) {
        const room = window.pga?.helpers?.getRoomScene?.();
        const cam = room?.cameras?.main;
        const canvas = document.querySelector("canvas");
        if (!entity || !canvas || !cam) return null; // chuyển world → screen
        const worldX = entity.x ?? 0;
        const worldY = entity.y ?? 0;
        const screenX = (worldX - cam.worldView.x) * cam.zoom;
        const screenY = (worldY - cam.worldView.y) * cam.zoom;
        const rect = canvas.getBoundingClientRect();
        const targetX = rect.left + screenX;
        const targetY = rect.top + screenY; // 🖱️ HUD bay đến vị trí entity
        await moveHudTo(targetX, targetY);
        return {
            x: screenX,
            y: screenY,
            worldX,
            worldY,
            center: {
                x: worldX,
                y: worldY
            },
            position: {
                x: worldX,
                y: worldY
            },
            leftButtonReleased: () => true,
            rightButtonReleased: () => false,
            leftButtonDown: () => false,
            rightButtonDown: () => false,
        };
    }
    async function moveHudTo(x, y, steps = 30, delay = 5) {
        const hud = document.querySelector('[class^="Hud_selectedItem__"]');
        if (!hud) return;

        const m = hud.style.transform.match(/translate3d\(([\d.-]+)px,\s*([\d.-]+)px/);
        let curX = m ? parseFloat(m[1]) : 0;
        let curY = m ? parseFloat(m[2]) : 0;
        const totalDist = Math.hypot(x - curX, y - curY);
        const stepsAuto = Math.max(15, Math.min(60, Math.floor(totalDist / 20)));
        const ease = t => 1 - Math.pow(1 - t, 3);

        for (let i = 1; i <= stepsAuto; i++) {
            const t = ease(i / stepsAuto);
            const nx = curX + (x - curX) * t;
            const ny = curY + (y - curY) * t;
            hud.style.transform = `translate3d(${nx}px, ${ny}px, 0px)`;
            await new Promise(r => setTimeout(r, delay));
        }
    }
    async function autoMineZeroDelayUltraPro_v4() {
        STOP_AUTOMINE = false;

        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room?.entities) return showMessage("❌ Không tìm thấy room.entities");

        drawAutoStatus(true, "AUTO MINING ACTIVE");
        showMessage("💎 Auto Mining Start");

        let lastCheck = 0;


        // 🔁 Vòng lặp chính
        async function loop() {
            if (STOP_AUTOMINE) {
                drawAutoStatus(false);
                return showMessage("🛑 Auto stopped!");
            }

            const now = performance.now();
            const nowUTC = Date.now();
            const redux = window.pga?.helpers?.getReduxValue?.();

            const selectedItem = redux?.storage?.selectedItem?.id ?? "";
            const health = redux?.storage?.selectedSlot?.state?.displayInfo?.health ?? 9999;
            const energy = redux?.game?.player?.full?.energy?.level ?? 9999;

            // phải cầm Pickaxe
            if (!selectedItem || !selectedItem.startsWith("itm_pickaxe_")) {
                STOP_AUTOMINE = true;
                drawAutoStatus(false);
                return showMessage("⚠️ Bạn không cầm Pickaxe — auto dừng!");
            }

            // kiểm tra tool / energy mỗi 0.25s
            if (now - lastCheck > 250) {
                if (health <= end_health) {
                    STOP_AUTOMINE = true;
                    drawAutoStatus(false);
                    //await window.pick_ball("itm_pickaxe_04");
                    window.emitGameEvent("CHANGE_PICK_PALL",!0);
                    return showMessage("🪓 Tool sắp hỏng! Dừng auto!");
                }
                if (energy <= 8) {
                    STOP_AUTOMINE = true;
                    drawAutoStatus(false);

                    if(window.endtimenow() <= 0){
                        window.emitGameEvent("GO_E_POWWER",!0);
                    }

                }
                lastCheck = now;
            }

            const entities = Array.from(room.entities.values());
            const selfPos = room.selfPlayer?.position;

            // 🔍 Lọc tất cả mỏ hợp lệ, KHÔNG giới hạn khoảng cách
            const mines = entities
            .filter((ent) => {
                const id = ent?.gameEntity?.id?.toLowerCase?.() || "";
                if (!id.startsWith("ent_mine_04")) return false;
                const s = (ent?.state?.state || ent?.state || ent?.properties?.state || "").toLowerCase();
                return ["waiting", "ready", "loaded"].includes(s);
            })
            .map(ent => ({
                ent,
                dist: Math.hypot((ent.x ?? 0) - selfPos.x, (ent.y ?? 0) - selfPos.y)
            }))
            .sort((a, b) => a.dist - b.dist)
            .map(obj => obj.ent);
            if (!window.pga.helpers.getRoomScene().selfPlayer.isMoving) {
                const nearMines = mines.filter(m => {
                    const dx = (m.x ?? 0) - selfPos.x;
                    const dy = (m.y ?? 0) - selfPos.y;
                    return Math.hypot(dx, dy) <= window.dist;
                });

                if (nearMines.length === 0) {
                    STOP_AUTOMINE = true;
                    drawAutoStatus(false);
                    showMessage("END! (Out of range)");
                    return goToVilla();
                }

                mines.length = 0;
                mines.push(...nearMines);
            }
            if (mines.length === 0) {
                requestAnimationFrame(loop);
                return;
            }

            let allLoaded = true;
            let allLong = true;

            for (const ent of mines) {
                const state = (ent?.state?.state || ent?.state || ent?.properties?.state || "").toLowerCase();
                const dist = Math.hypot((ent.x ?? 0) - selfPos.x, (ent.y ?? 0) - selfPos.y);

                try {
                    if (state === "ready") {
                        allLoaded = false;
                        if (dist <=  window.dist && !STOP_AUTOMINE) {
                            const pointer = await makePointerForEntity(ent);
                            ent.clicked(pointer, {});
                            ent.clicked(pointer, {});
                        }
                    } else if (state === "waiting") {
                        allLoaded = false;
                        if (dist <=  window.dist && !STOP_AUTOMINE ) {
                            const pointer = await makePointerForEntity(ent);
                            ent.clicked(pointer, {});
                        }
                    } else if (state === "loaded") {
                        const utcTarget = ent?.currentState?.displayInfo?.utcTarget || 0;
                        if (utcTarget > nowUTC) {
                            const remain = (utcTarget - nowUTC) / 1000;
                            if (remain > 10 && remain < 300 && window.timerone == true) {
                                //function rảnh tay
                            }
                            if (remain < 20 && remain > 0) {
                                allLong = false;
                                continue;
                            } else if (remain <= 0) {
                                if (dist <=  window.dist && !STOP_AUTOMINE) {
                                    const pointer = await makePointerForEntity(ent);
                                    ent.clicked(pointer, {});
                                }
                                //console.log(`⛏️ Bắt đầu lại mỏ @(${ent.x},${ent.y})`);
                                allLoaded = false;
                                allLong = false;
                            } else if (remain < 120) {
                                allLong = false;
                            }
                        } else {
                            allLong = false;
                        }
                    }
                } catch (err) {
                    console.warn("⚠️ Lỗi click mỏ:", err);
                }
            }

            // nếu tất cả mỏ đã loaded lâu → dừng auto
            if (allLoaded && allLong) {
                STOP_AUTOMINE = true;
                drawAutoStatus(false);
                showMessage("END!");
                return goToVilla();
            }

            requestAnimationFrame(loop);
        }

        loop();
    }
    async function autoChopTreesVerticalProgressiveFast() {
        STOP_AUTO = false;

        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room?.entities) return showMessage("❌ Không tìm thấy room.entities");

        const entities = Array.from(room.entities.values());

        // 🌲 Lọc cây bắt đầu bằng ent_tree và state = mature hoặc stump
        const trees = entities.filter((ent) => {
            const id = ent?.gameEntity?.id?.toLowerCase?.() || "";
            const s =
                  (ent?.state?.state ||
                   ent?.state ||
                   ent?.properties?.state ||
                   ent?.properties?.growthStage ||
                   ""
                  ).toString().toLowerCase();
            return id.startsWith("ent_tree") && ["mature", "stump"].includes(s);
        });

        if (!trees.length) return showMessage("✅ Không có cây nào để chặt.");

        // 🧭 Gom nhóm cây theo cột (theo X, làm tròn)
        const columns = {};
        for (const t of trees) {
            const x = Math.round(t.x / 10) * 10;
            if (!columns[x]) columns[x] = [];
            columns[x].push(t);
        }

        const sortedX = Object.keys(columns)
        .map(Number)
        .sort((a, b) => a - b);

        showMessage(`🌲 Auto chặt siêu tốc | Dừng khi tool sắp hỏng hoặc energy thấp`);
        console.log("⏳ Nhấn [S] để DỪNG KHẨN CẤP!");

        let reverse = false;

        for (;;) {
            const cols = reverse ? [...sortedX].reverse() : sortedX;

            for (const x of cols) {
                if (STOP_AUTO) return stopMsg("🛑 Dừng khẩn cấp!");

                let col = columns[x].sort((a, b) => a.y - b.y);
                console.log(`🌳 Chặt cột X=${x} (${col.length} cây)`);

                while (!STOP_AUTO) {
                    let active = 0;

                    for (const tree of col) {
                        if (STOP_AUTO) break;

                        // ⚠️ Kiểm tra health & energy TRƯỚC KHI CLICK
                        const redux = window.pga?.helpers?.getReduxValue?.();
                        const health =
                              redux?.storage?.selectedSlot?.state?.displayInfo?.health ?? 9999;
                        const energy = redux?.game?.player?.full?.energy?.level ?? 9999;

                        if (health <= 1) {
                            STOP_AUTO = true;
                            return showMessage("🛑 Tool sắp hỏng! Dừng auto ngay!");
                        }
                        if (energy <= 4) {
                            STOP_AUTO = true;
                            return showMessage("🪫 Energy quá thấp (<4)! Dừng auto!");
                        }

                        // 🔍 Kiểm tra trạng thái cây
                        const state =
                              (tree?.state?.state ||
                               tree?.state ||
                               tree?.properties?.state ||
                               tree?.properties?.growthStage ||
                               ""
                              ).toString().toLowerCase();

                        // 🌱 Nếu cây đã thành seed → coi như xong, bỏ qua
                        if (state === "seed") continue;

                        // 🪓 Chặt nếu còn mature hoặc stump
                        if (["mature", "stump"].includes(state)) {
                            active++;
                            await simulateEntityClick(tree);
                            await sleep(40 + Math.random() * 30); // ⚡ 40–70 ms giữa click
                        }
                    }

                    if (active === 0) {
                        console.log(`✅ Cột X=${x} xong (tất cả thành seed)!`);
                        break;
                    }

                    await sleep(80); // nghỉ ngắn giữa vòng
                }

                await sleep(120); // nghỉ nhẹ giữa hàng
            }

            reverse = !reverse; // đảo chiều sau mỗi vòng
        }

        // Helpers
        function stopMsg(msg) {
            showMessage(msg);
            console.warn(msg);
        }

        function sleep(ms) {
            return new Promise((r) => setTimeout(r, ms));
        }
    }
    async function safeCheckHeldItem() {
        for (let i = 0; i < 10; i++) {
            try {
                const redux = window.pga?.helpers?.getReduxValue?.();
                if (redux?.storage?.selectedItem !== undefined) {
                    const item = redux.storage.selectedItem;
                    return item.id;
                }
            } catch (e) {
                // Redux chưa attach -> chờ thêm
            }
            await new Promise(r => setTimeout(r, 200)); // đợi 0.2s rồi thử lại
        }
        console.warn("⚠️ Redux chưa sẵn sàng sau 2s");
    }
    async function auto_turn_on() {
        if (window.auto !== 'on') return;

        const itemId = await safeCheckHeldItem();
        if (itemId?.startsWith("itm_pickaxe_")) {

            autoMineZeroDelayUltraPro_v4();
        }
        if (itemId === "itm_silkslug") {
            collectEmptySluggery();
        }
    }
    let lastCollectTime = 0; // thời gian gọi cuối (ms)

    async function collectEmptySluggery() {
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room?.entities) return console.warn("⚠️ Không tìm thấy room.entities");
        const targets = [...room.entities.values()].filter(e => {
            if (!e) return false;
            const id = e?.gameEntity?.id?.toLowerCase?.() || "";
            return id.includes("ent_sluggery") && e.state === "empty";
        });

        if (!targets) return false;
        for (const ent of targets) {
            const id = ent?.gameEntity?.id || "";
            try {
                ent.clicked(window.makePointerForEntity(ent), {});
                await new Promise(r => setTimeout(r, 150 + Math.random() * 80));
            } catch (err) {
            }
        }
        window.showMessage("xong dòi")
    }

    async function safeCollectReadyStations() {
        const now = Date.now();
        if (now - lastCollectTime < 5_000) {
            // 🚫 Nếu chưa đủ 10 giây thì bỏ qua
            const remain = ((5_000 - (now - lastCollectTime)) / 1000).toFixed(1);
            // console.log(`⏳ Chờ ${remain}s nữa để collectReadyStations`);
            return;
        }

        lastCollectTime = now;

        try {
            // console.log("⚙️ Gọi collectReadyStations()");
            await collectReadyStations();
        } catch (err) {
            //console.error("❌ Lỗi khi gọi collectReadyStations:", err);
        }
    }
    function go_to_sauna_powwer(){
        window.goland()
    }
    waitForOnGameEvent(() => {
        window.onGameEvent("RELEASE_FROM_CURSOR", auto_turn_on);
        window.onGameEvent("GO_HOME_TELE",goToVilla );
        window.onGameEvent("DEPE_POWER",window.depositE );
        window.onGameEvent("GO_E_POWWER",go_to_sauna_powwer );
        window.onGameEvent("CHANGE_PICK_PALL", () => {
            window.timerone = true;
        });
        //window.onGameEvent("CURSOR_CHANGER",goToVilla );
    })
    /************ ⌨️ PHÍM TẮT ************/
    document.addEventListener("keydown", e => {
        // if (e.code === "Delete") clickAllCropsSmart(); // Bắt đầu auto
        if (e.code === "PageUp") autoMineZeroDelayUltraPro_v4(); // Bắt đầu auto
        if (e.code === "PageDown") autoChopTreesVerticalProgressiveFast(); // Bắt đầu auto
        if (e.code === "Space") {STOP_AUTO = true; STOP_AUTOMINE = true;drawAutoStatus(false);};// Dừng khẩn cấp
    });

    window.triger_mine_auto = autoMineZeroDelayUltraPro_v4;
})();
