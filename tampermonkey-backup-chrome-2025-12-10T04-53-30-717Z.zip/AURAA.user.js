// ==UserScript==
// @name         AURAA
// @namespace    pixels
// @version      2.0
// @match        *://play.pixels.xyz/*
// @grant        none
// ==/UserScript==

(function () {
    let auraSelf = null;
    let auraOthers = {};

    window.AURA_CONFIG = {
        enabled: false,
        url: "https://d31ss916pli4td.cloudfront.net/uploadedAssets//7e2caf6f-182b-4e0b-b2e6-97bca25dc8d3.png",
        scaleX: 0.55,
        scaleY: 0.45,
        offsetX: 10,
        offsetY: 12,
        alpha: 0.9,
        tint: "#FF0000",
        blend: "ADD",
        rotationSpeed: 0.015
    };

    // ⭐ Declare BLEND_MAP in outer scope
    let BLEND_MAP = null;

    function waitPhaser(callback) {
        const t = setInterval(() => {
            if (window.Phaser?.BlendModes) {
                clearInterval(t);
                callback();
            }
        }, 100);
    }

    // ==============================
    // SAFE ROOM GETTER
    // ==============================
    function getRoom() {
        const r = window.pga?.helpers?.getRoomScene?.();
        return (r && r.selfPlayer) ? r : null;
    }
    function getOtherPlayers() {
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room || !room.otherPlayers) return [];
        return [...room.otherPlayers.values()];
    }

    function waitRoom(cb) {
        const timer = setInterval(() => {
            const r = getRoom();
            if (r) {
                clearInterval(timer);
                cb(r);
            }
        }, 150);
    }

    // AURA SYSTEM
    let aura = null;
    let currentRoom = null;
    let textureKey = null;

    function loadAuraTexture(room, url) {
        return new Promise(resolve => {
            textureKey = "aura_" + Date.now();
            room.load.once("complete", resolve);
            room.load.image(textureKey, url);
            room.load.start();
        });
    }

    function spawnAura() {
        const room = getRoom();
        if (!room) return;

        const CFG = window.AURA_CONFIG;

        // ========== AURA CHO BẢN THÂN ==========
        if (!auraSelf) {
            auraSelf = room.add.sprite(0, 0, textureKey);
            auraSelf.setOrigin(0.5);
            auraSelf.setAlpha(CFG.alpha);
            auraSelf.setScale(CFG.scaleX, CFG.scaleY);
            auraSelf.setBlendMode(BLEND_MAP[CFG.blend]);
        }

        // ========== AURA CHO NGƯỜI KHÁC ==========
        const others = getOtherPlayers();
        for (const op of others) {

            const id = op?.playerCore?.mid;
            if (!id) continue;   // skip nếu player chưa load mid

            if (!auraOthers[id]) {
                auraOthers[id] = spawnAuraForPlayer(room, op);
            }
        }


        room.events.on("postupdate", updateAura);
       // console.log("Aura (self + others) -> ON");
    }//
    function spawnAuraForPlayer(room, player) {
        const CFG = window.AURA_CONFIG;

        const a = room.add.sprite(0, 0, textureKey);
        a.setOrigin(0.5);
        a.setScale(CFG.scaleX / 2, CFG.scaleY / 2);
        const fc = player?.playerCore.faction ?? 0;
        a.setTint(tintByFacing(fc));

        a.setAlpha(CFG.alpha);
        a.setBlendMode(BLEND_MAP[CFG.blend]);

        return a;
    }

    function removeAura() {
        const room = getRoom();
        if (!room) return;

        room.events.off("postupdate", updateAura);

        // Remove self
        if (auraSelf) {
            auraSelf.destroy();
            auraSelf = null;
        }

        // Remove others
        for (const id in auraOthers) {
            auraOthers[id].destroy();
            delete auraOthers[id];
        }

        //console.log("Aura (self + others) -> OFF");
    }
    function updateAura() {
        const room = getRoom();
        const CFG = window.AURA_CONFIG;

        if (!room) return;

        // ======= UPDATE AURA CỦA MÌNH =======
        const p = room.selfPlayer;
        if (auraSelf && p?.bodyPosition) {
            auraSelf.x = p.bodyPosition.x + CFG.offsetX;
            auraSelf.y = p.bodyPosition.y + CFG.offsetY;
            auraSelf.setScale(CFG.scaleX, CFG.scaleY);
            //auraSelf.rotation += CFG.rotationSpeed;
            auraSelf.setDepth(p.position.y - 5);

            // cập nhật tint/blend/alpha nếu config thay đổi
            auraSelf.setTint(setAuraTint(CFG.tint));
            auraSelf.setBlendMode(BLEND_MAP[CFG.blend]);
            auraSelf.setAlpha(CFG.alpha);
        }

        // ======= UPDATE AURA NGƯỜI KHÁC =======
        const others = getOtherPlayers();
        const idsNow = new Set();

        for (const op of others) {
            const id = op?.playerCore?.mid;
            if (!id) continue;

            idsNow.add(id);

            if (!auraOthers[id]) {
                auraOthers[id] = spawnAuraForPlayer(room, op);
            }

            const a = auraOthers[id];

            // Position
            a.x = op.bodyPosition.x + CFG.offsetX;
            a.y = op.bodyPosition.y + CFG.offsetY;
            a.setDepth(op.position.y - 5);
            a.setScale(CFG.scaleX / 2 , CFG.scaleY / 2);

            // ⭐ TINT THEO FACING ⭐
            const fc = op?.playerCore.faction ?? 0;
            //console.log(fc)
            a.setTint(tintByFacing(fc));

            // Blend mode + alpha giống config
            a.setBlendMode(BLEND_MAP[CFG.blend]);
            a.setAlpha(CFG.alpha);
        }

        // ======= XOÁ AURA CỦA NGƯỜI ĐÃ RỜI MAP =======
        for (const id in auraOthers) {
            if (!idsNow.has(id)) {
                auraOthers[id].destroy();
                delete auraOthers[id];
            }
        }
    }


    function setAuraTint(colorStr) {
        const hex = Number("0x" + colorStr.replace("#", ""));
        return hex;
    }
    function tintByFacing(facing) {
        switch (facing) {
            case "1": return 0x00FF00; // xanh
            case "2": return 0xFFFF00; // vàng
            case "3": return 0xFF0000; // đỏ
            default: return 0xFFFFFF; // nếu chưa load facing
        }
    }
    // AUTO RELOAD ON ROOM CHANGE
    async function initAuraLoop() {
        waitRoom(async (room) => {
            const newRoom = getRoom();
            if (!newRoom) return;

            if (newRoom !== currentRoom) {
                //console.log("🔁 Room changed → reload aura");
                removeAura();
                currentRoom = newRoom;

                await loadAuraTexture(newRoom, window.AURA_CONFIG.url);
            }

            if (window.AURA_CONFIG.enabled) spawnAura();
            else removeAura();

            setTimeout(initAuraLoop, 500);
        });
    }

    // ==============================
    // START — WAIT FOR PHASER
    // ==============================
    waitPhaser(() => {

        // ⭐ Assign BLEND_MAP when Phaser is ready
        BLEND_MAP = {
            ADD: Phaser.BlendModes.ADD,
            SCREEN: Phaser.BlendModes.SCREEN,
            MULTIPLY: Phaser.BlendModes.MULTIPLY,
            COLOR_DODGE: Phaser.BlendModes.COLOR_DODGE,
            OVERLAY: Phaser.BlendModes.OVERLAY
        };

        initAuraLoop();
    });

})();
