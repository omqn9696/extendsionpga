// ==UserScript==
// @name         Khai báo các biến window global
// @version      1.4
// @description  khai báo
// @icon         https://img.icons8.com/fluency/48/closed-window--v1.png
// @author       GaoOM.AI
// @match        *://play.pixels.xyz/*
// @updateURL    https://raw.githubusercontent.com/omqn9696/extendsionpga/refs/heads/main/trigerphaser.user.js
// @downloadURL  https://raw.githubusercontent.com/omqn9696/extendsionpga/refs/heads/main/trigerphaser.meta.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    const E_lv = 200;// E sẽ bơm khi thấp hơn
    window.end_heath = 0.7; // % máu của vật phấm lấy
    window.speed_up = 0; // khởi tạo speed up
   /* window.friend = [
    "Daniel_xD",
    "[GG] Swoosh",
    "Utoy|DocGelle",
    "💎888💎MehrSaa",
    "maami",
    "[GG] Hyukin.",
    "GaoOM.AI",
    "CURSEWILLZ",
    "Girl.beo",
    "YHANskie1"
]*/

    window.showMessage = showMessage;
    window.depositE = Energy_click;//function bơm E
    window.endtimenow = endtimenow
    window.backlist = () => {
        return JSON.parse(localStorage.getItem('backlistLand'));
    };
    function endtimenow(){
        return window.timerscheck[0].endTime - Date.now();
    }
    window.syncFriend = async function () {
    const url = "https://n8n.exquisitefly.net/webhook/mapid?type=friend";

    try {
        const res = await fetch(url);
        const data = await res.json();   // data = [ { players: [...] } ]

        let list = [];

        // dạng: [ { players: [...] } ]
        if (Array.isArray(data) && data.length > 0 && Array.isArray(data[0].players)) {
            list = data[0].players;
        } else {
            //console.warn("Webhook JSON không đúng format:", data);
            return;
        }

        window.friend = list.map(v => String(v).trim());


    } catch (err) {

    }
};
        window.syncFriend();
    async function Energy_click( itm = "itm_energyDrink_barney"){
        if(window.pga.helpers.getPlayerState().energy.level < E_lv && window.mine_tiger === 4 && window.endtimenow() > 0){
            await window.pick_ball(itm)//cam do len
            if(window.pga.helpers.getReduxValue().storage.selectedItem.id === itm ){
                const pointer = await makePointerForEntity(pga.helpers.getRoomScene().selfPlayer.position);
                window.pga.helpers.getRoomScene().selfPlayer.clicked(pointer, {})
            }
        }else{
            showMessage("còn quá nhiều E")
        }
    }
    window.gohome = goToSpeck;
    function goToSpeck() {
        const targets = document.querySelectorAll(".Hud_outside__zzIGQ");
        for (const el of targets) {
            const img = el.querySelector('img[aria-label="Land and Bookmarks"]');
            if (!img) continue;

            // mở popup Land & Travel
            el.click();

            setTimeout(() => {
                const btnContainer = document.querySelector(".LandAndTravel_customHeader__goUPo");
                if (!btnContainer) return;

                // tìm ô "My Speck" trong danh sách
                const items = document.querySelectorAll('.LandAndTravel_mapSquare__LuVEh.clickable');
                for (const item of items) {
                    const label = item.querySelector('.LandAndTravel_mapText__hEuVl');
                    if (label && label.textContent.trim() === 'My Speck') {
                        item.click();
                        break;
                    }
                }
            }, 1000);

            break;
        }
    }
    function click_ent(ent){
        const port = getenties(ent);
        port[0].clicked(window.makePointerForEntity(port[0]), {})
    }
    window.click_ent = click_ent;
    window.goland = goland
    function getenties(ent) {
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room?.entities) return [];

        const list = [...room.entities.values()];

        return list.filter(e => {
            const id = e?.gameEntity?.id || "";
            return  id === ent

        });
    }
    function waitForElement(selector, timeout = 5000) {
        return new Promise((resolve, reject) => {
            const start = performance.now();

            const timer = setInterval(() => {
                const el = document.querySelector(selector);
                if (el) {
                    clearInterval(timer);
                    resolve(el);
                }
                if (performance.now() - start > timeout) {
                    clearInterval(timer);
                    reject("Timeout: " + selector);
                }
            }, 50);
        });
    }

    async function goland() {
        const targets = document.querySelectorAll(".Hud_outside__zzIGQ");

        for (const el of targets) {
            const img = el.querySelector('img[aria-label="Land and Bookmarks"]');
            if (!img) continue;

            // click biểu tượng Land
            el.click();

            // 🔥 Đợi tab render xong rồi mới thao tác
            await waitForElement(".LandAndTravel_tab__LD39V");

            const tabs = document.querySelectorAll(".LandAndTravel_tab__LD39V");
            if (tabs[2]) tabs[2].click();
            else return console.warn("❌ Không tìm thấy tab thứ 3");

            // 🔥 Đợi list map load
            await waitForElement(".LandAndTravel_mapSquare__LuVEh.clickable");

            const items = document.querySelectorAll('.LandAndTravel_mapSquare__LuVEh.clickable');

            for (const item of items) {
                const label = item.querySelector('.LandAndTravel_mapId__2nojt');
                if (label && label.textContent.trim() === '#2218') {
                    item.click();
                    console.log("✔ Đã click My Speck #2218");
                    break;
                }
            }

            break;
        }
    }
    function showMessage(msg, mod = "player") {
        let player = window.pga?.helpers?.getRoomScene?.()?.selfPlayer;
        if (!player) return;
        if (mod === "pet" && player.petNode) {
            player = player.petNode;
        }
        const text = String(msg).trim().toLowerCase();
        const templates = {
            "stop": "Auto Stop",
            "not_item": "Item không phù hợp",
            "end_item": "Hết item để sử dụng",
            "finish": "Auto Done",
            "start": "Auto start",
            "error": "❌ Có lỗi xảy ra!",
        };
        if (templates[text]) {
            player.showChatMessage(templates[text]);
        } else {
            player.showChatMessage(msg);
        }
    }
    function check_gate() {
        const room = window.pga.helpers.getRoomScene();
        if (!room?.entities) return false;

        for (const ent of room.entities.values()) {
            if (ent?.gameEntity?.id === "ent_gate" &&
                ent?.currentState?.state === "closed")
            {
                return true;
            }
        }
        return false;
    }
    window.check_user =check_user;
    window.check_gate =check_gate;
    window.clear_gate =clear_gate;

    function checkNoFriend() {
        const friends = window.friend || [];
        const others = window.pga.helpers.getRoomScene().otherPlayers;
        if (!others) return true;

        for (const other of others.values()) {
            const name = other.playerData?.label || "";
            if (friends.includes(name)) {
                return false; // ❌ có friend → trả về false
            }
        }

        return true; // ✅ không có friend nào → true
    }
    window.checkNoFriend = checkNoFriend;
    function check_user(t) {
        const others = window.pga.helpers.getRoomScene().otherPlayers;

        for (const other of others.values()) {
            if (other.playerData?.label === t) {
                return true;    // tìm thấy → trả về luôn
            }
        }
        return false; // không tìm thấy
    }
    function clear_gate(){
        const room = window.pga.helpers.getRoomScene();
        if (!room?.entities) return false;

        for (const ent of room.entities.values()) {
            if (ent?.gameEntity?.id === "ent_gate")
            {
                ent.destroy()
            }
        }
    }
    window.getMatchingFarms = async () => {

        // lấy blacklist (mảng), nếu null → []
        const blacklist = window.backlist?.() || [];

        // normalize để so sánh: chỉ giữ số ID
        const blacklistClean = blacklist.map(id => id.replace("pixelsNFTFarm-", "").trim());

        async function fetchList(landtypes = "space") {
            const url = `https://industry.guildpal.com/v2/entities/ent_mine_04?landtypes=${landtypes}&count=60&includeHouse=false`;
            const res = await fetch(url);
            const data = await res.json();
            return data?.[0]?.public || [];
        }

        function filterValid(list) {
            return list
                .filter(pub => pub.numPlayers === 0)                   // farm trống
                .filter(land => {
                const id = land.landName.replace("pixelsNFTFarm-", "");

                // ❌ loại farm có trong blacklist
                if (blacklistClean.includes(id)) return false;

                const validEntitiesCount = land.numberOfAvailableEntities !== 1 && land.numberOfEntities >= 5;

                const hasValidWaiting = land.entities.some(e => e.waiting <= 60000);

                let waitingDiffOk = true;
                if (land.entities?.length > 0) {
                    const waitings = land.entities.map(e => e.waiting);
                    waitingDiffOk = (Math.max(...waitings) - Math.min(...waitings)) <= 90000;
                }

                return validEntitiesCount && hasValidWaiting && waitingDiffOk;
            });
        }

        // -------- FETCH SPACE --------
        let list = filterValid(await fetchList("space"));

        const recorded = Object.keys(window.player_position || {});
        let matched = list.filter(pub => recorded.includes(pub.landName));

        // Nếu SPACE trống → thử WATER
        if (matched.length === 0 && list.length === 0) {
            console.log("⚠️ SPACE empty → checking WATER…");

            let waterList = filterValid(await fetchList("water"));
            let waterMatched = waterList.filter(pub => recorded.includes(pub.landName));

            return waterMatched.length === 0 ? waterList : waterMatched;
        }

        return matched.length === 0 ? list : matched;
    };
    async function makePointerForEntity(entity) {
        const room = window.pga?.helpers?.getRoomScene?.();
        const cam = room?.cameras?.main;
        const canvas = document.querySelector("canvas");
        if (!entity || !canvas || !cam) return null; // chuyển world → screen
        const worldX = entity.x ?? 0;
        const worldY = entity.y ?? 0;
        const screenX = (worldX - cam.worldView.x) * cam.zoom;
        const screenY = (worldY - cam.worldView.y) * cam.zoom;
        const rect = canvas.getBoundingClientRect();
        const targetX = rect.left + screenX;
        const targetY = rect.top + screenY; // 🖱️ HUD bay đến vị trí entity
        // await moveHudTo(targetX, targetY);
        return {
            x: screenX,
            y: screenY,
            worldX,
            worldY,
            center: {
                x: worldX,
                y: worldY
            },
            position: {
                x: worldX,
                y: worldY
            },
            leftButtonReleased: () => true,
            rightButtonReleased: () => false,
            leftButtonDown: () => false,
            rightButtonDown: () => false,
        };
    }
    window.mod_skin = mod_skin;
    function mod_skin(){
        if(window.pga.helpers.getRoomScene()){
            window.timerone = true
          /*  const a =  window.pga.helpers.getRoomScene().selfPlayer.playerData;
            a.avatar.display ={
                "avatarId": "pixelkittens",
                "tokenId": "24",
                "symbol": "KITTY",
                "nft": true,
                "image": "ipfs://bafybeidednooqacfa7ll57evvisgoxechmwfq7iw6painhhjfmelgrg5be/24",
                "name": "Pixel Kittens24",
                "chain": "ronin",
                "full": "none",
                "background": "mint",
                "eyes": "pinkcyclops",
                "fur": "lightening",
                "headwear": "karateheadband",
                "mouth": "blush"

            }

            delete a.kind,
                window.pga.helpers.getRoomScene().selfPlayer.updatePlayerData((a)),
                window.pga.helpers.getRoomScene().removeNode( window.pga.helpers.getRoomScene().selfPlayer),
                window.pga.helpers.getRoomScene().nodesToAdd.push(window.pga.helpers.getRoomScene().selfPlayer)*/

        }
    }
})();