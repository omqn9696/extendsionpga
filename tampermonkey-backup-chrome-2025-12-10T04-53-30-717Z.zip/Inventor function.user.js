// ==UserScript==
// @name         Inventor function
// @namespace    pixels
// @icon          https://img.icons8.com/color/48/shopaholic.png
// @version      1.3
// @description  tự động qs 60S
// @author       Drayke
// @match        *://play.pixels.xyz/*
// @grant        none
// ==/UserScript==


(function() {

    'use strict';
    const makePointerForEntity = window.makePointerForEntity;
    window.releaseCusor = releaseCusor;
    window.getStoragesByNameAndSlots = getStoragesByNameAndSlots;
    window.getUniqueFilteredInventory = getUniqueFilteredInventory;
    window.openChest = openChest;
    window.findchest = findchest;
    window.moveAll = moveAll;
    window.getinventor = getinventor;
   // window.getPickaxe_end_slot = getPickaxe_end_slot;

    async function change_pixel(){
        const slot_end = int_Pickaxe_end_slot();
        const chest_end =  window.getStoragesByNameAndSlots("itm_pickaxe_04_end");
        window.openChest(chest_end[0].mid);
        await clickHotbarShortcut(slot_end[0] + 1, true);
        await closeChest();
    }
    async function moveAll() {
        const removeList = [
            "itm_energyDrink_barney",
            "itm_pickaxe_04","itm_runningShoe_basic"
        ];

        const id_ivt = getUniqueFilteredInventory(removeList);

        for (const item of id_ivt) {
            console.log("👉 Đang xử lý:", item);

            await window.findchest(item);  // 🔥 Đợi xong từng chest

            await delay(1000); // nghỉ nhẹ cho an toàn
        }

        console.log("🎉 Tất cả item đã move xong!");
    }

    const evt = new MouseEvent("contextmenu", {
        bubbles: true,
        cancelable: true,
        button: 2,   // chuột phải
        buttons: 2
    });
    async function findchest(id) {
    const chests = window.getStoragesByNameAndSlots(id); // tất cả chest
    if (!chests.length) {
        console.warn("❌ Không tìm thấy chest nào chứa:", id);
        return;
    }

    let slotsInv = getInventorySlotsById(id); // slot inventory ban đầu

    console.log("📦 Found chests:", chests.length);
    console.log("🎒 Inventory slots:", slotsInv);

    // 🔁 Lặp qua từng chest
    for (let i = 0; i < chests.length; i++) {
        const chest = chests[i];
        const totalSlots = chest.totalSlots;
        const slotempty = totalSlots - chest.slotCount;

        console.log(`\n====== Chest ${i + 1}/${chests.length} ======`);
        console.log("Slot trống:", slotempty);

        // Nếu chest đầy → bỏ qua, chọn chest tiếp theo
        if (slotempty <= 0) {
            console.log("⚠ Chest đầy → chuyển chest khác...");
            continue;
        }

        // Mở chest
       await  window.openChest(chest.chest.mid);
        await delay(120);

        // Sau khi mở kiểm tra lại inventory
        slotsInv = getInventorySlotsById(id);
        if (!slotsInv.length) {
            console.log("🎉 Đã hết item trong inventory → xong");
            await closeChest();
            return;
        }

        console.log("🎒 Slots inventory hiện tại:", slotsInv);

        // số slot cần chuyển vào chest
        const need = Math.min(slotsInv.length, slotempty);

        console.log(`🔥 Move ${need} slot`);

        // Move đủ số slot
        for (let j = 0; j < need; j++) {
            const slot = slotsInv[j];
            await delay(400);
            await clickHotbarShortcut(slot + 1, true);
        }

        await delay(150);

        // đóng chest trước khi chuyển qua chest tiếp theo
       await  closeChest();

        // cập nhật inventory sau khi move
        slotsInv = await getInventorySlotsById(id);

        if (!slotsInv.length) {
            console.log("🎉 Hết item → dừng toàn bộ.");
            return;
        }
    }
await closeChest();
    console.log("🔚 Đã kiểm tra tất cả chest.");
}

    function getUniqueFilteredInventory(removeIds = []) {
    const inv = window.pga?.helpers?.getInventoryItems?.();
    if (!inv) return [];

    const removeSet = new Set(removeIds);
    const seen = new Set();
    const result = [];

    for (const it of inv) {
        if (removeSet.has(it.id)) continue; // loại id cấm

        if (!seen.has(it.id)) {
            seen.add(it.id);
            result.push(it.id); // chỉ push lần đầu
        }
    }

    return result;
}
    function closeChest() {
    const btn = document.querySelector(".InventoryWindow_closeBtn__ioczI");
    if (btn) {
        btn.click();
        console.log("📕 Đã đóng chest");
    }
}

    //getInventorySlotsById("itm_roughstone_04")
    function getInventorySlotsById(itemId) {
    const inv = window.pga?.helpers?.getInventoryItems?.();
    if (!inv) return [];

    return inv
        .filter(it => it.id === itemId && it.quantity === 999)
        .map(it => it.slot);  // chỉ lấy slot
}

function getinventor() {
      var _a, _b, _c, _d;
      const roomScene = window.pga.helpers.getRoomScene();
      const inventorySlots = (_d = (_c = (_b = (_a = roomScene == null ? void 0 : roomScene.stateManager) == null ? void 0 : _a.playerSerializer) == null ? void 0 : _b.state) == null ? void 0 : _c.inventory) == null ? void 0 : _d.slots;
      if (!inventorySlots)
        return [];
      const inventorySlotItems = inventorySlots["$items"];
      if (!inventorySlotItems)
        return [];
      const result = [];
      inventorySlotItems.forEach((el) => {
        if (el && el.item) {
          result.push({
            id: el.item,
            slot: el.slot,
            quantity: el.quantity || 0,
            state:el.state || null
          });
        }
      });
      return result;
    }
    function int_Pickaxe_end_slot() {
    const inv = getinventor(); // dùng hàm bạn đã tạo ở trên
    if (!Array.isArray(inv)) return [];

    return inv
        .filter(el =>
            el.id === "itm_pickaxe_04" &&
            el.state &&
            el.state.displayInfo &&
            typeof el.state.displayInfo.health === "number" &&
            el.state.displayInfo.health < 1
        )
        .map(el => el.slot);
}

    function openChest(mid) {
    const room = window.pga?.helpers?.getRoomScene?.();
    if (!room) return console.warn("Không tìm thấy room");

    const entity = room.entities.get(mid);
    if (!entity) return console.warn("Không tìm thấy entity", mid);

    const pointer = makePointerForEntity(entity);

    try {
        entity.clicked(pointer, {});
        console.log("📦 Open chest:", mid);
    } catch (e) {
        console.error("❌ Lỗi mở chest:", mid, e);
    }
}
function getStoragesHasPickaxe(name = "itm_pickaxe_04") {
    const storages = window.pga?.helpers?.getPlayerStorages?.();
    if (!storages) return [];

    const result = [];

    for (const s of storages) {
        if (s?.storage?.name !== name) continue;

        const slots = s.storage.slots;
        let hasPickaxe = false;

        for (const key in slots) {
            const slot = slots[key];
            if (slot && slot.item === name) {
                hasPickaxe = true;
                break;
            }
        }

        if (hasPickaxe) {
            result.push(s); // trả về nguyên object s
        }
    }

    return result;
}
function getFirstValidPickaxeSlot(name = "itm_pickaxe_04") {
    const storages = window.pga?.helpers?.getPlayerStorages?.();
    if (!storages) return [];

    const out = [];

    for (const s of storages) {
        if (s?.storage?.name !== name) continue;

        const slots = s.storage.slots;
        if (!slots) continue;

        let found = null;

        for (const key in slots) {
            const slot = slots[key];
            if (!slot || slot.item !== name) continue;

            const st = slot.state;

            // điều kiện hợp lệ:
            const valid =
                !st ||                                   // state = null
                (st?.displayInfo?.health > 1);           // hoặc health > 1

            if (valid) {
                found = {
                    mid: s.mid,
                    slot: slot
                };
                break; // chỉ lấy slot đầu tiên
            }
        }

        if (found) out.push(found);
    }

    return out;
}
    function getStoragesByNameAndSlots(name) {
    const storages = window.pga?.helpers?.getPlayerStorages?.();
    if (!storages) return [];

    const result = [];

    for (const s of storages) {
        if (s?.storage?.name !== name) continue;

        const totalSlots = s.storage.size;
        const slotObj = s.storage?.slots || {};

        // 🔥 Đếm đúng số slot đang có item
        const slotCount = Object.keys(slotObj).length;
        if (slotCount < totalSlots) {
            result.push({
                chest: s,
                slotCount,
                totalSlots,
            });
        }
    }

    return result;
}
    const Eventmouse = {
        preventDefault(){},
        stopPropagation(){},
        button:0,
        isTrusted:true
    };
     const rightmouse = {
        preventDefault(){},
        stopPropagation(){},
        button:1,
        isTrusted:true
    };

    async function releaseCusor(){
        if(window.pga.helpers.getReduxValue().storage.selectedEquipment  !== -1){
            await delay(30);
            document.querySelector(".Hud_item__YGtIC.Hud_selected__k_eUw").click(Eventmouse)
            await delay(30);

        }
    }

    async function clickHotbarShortcut(number,mouse=false) {
        const items = document.querySelectorAll(".Hud_item__YGtIC");

        for (const el of items) {
            const shortcutEl = el.querySelector(".Hud_shortcut__UvE3h");
            if (!shortcutEl) continue;

            const shortcutValue = shortcutEl.textContent.trim();

            if (shortcutValue == number) {

                await delay(30);
                if(mouse){
                    shortcutEl.dispatchEvent(evt);

                }else{
                    el.click();
                }
                console.log(`🔥 CLICK HOTBAR SHORTCUT: ${number}`);
                return;
            }
        }

        console.warn(`❌ Không tìm thấy HUD shortcut = ${number}`);
    }
    function getHealthySlots(id_pick) {
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room) return [];

        const slots = room.stateManager.currentPlayer.full.inventory.slots.$items;

        let exists = false;
        for (const [, data] of slots.entries()) {
            if (data?.item === id_pick) {
                exists = true;
                break;
            }
        }

        if (!exists) {
            return [];
        }

        const results = [];

        for (const [slot, data] of slots.entries()) {
            if (!data) continue;

            const itemId = data.item;

            let health = data.state?.displayInfo?.health;
            if (health === undefined || health === null) {
                health = 1; // health undefined → 100%
            }

            if (itemId === id_pick && health > window.end_heath) {
                results.push(Number(slot));
            }
        }

        return results;
    }
    function delay(ms = 30) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async  function auto_pixa(id_pick){
        await releaseCusor()//nhả đồ đang cầm trước
        const slot =   getHealthySlots(id_pick)// lấy all slot nhiều máu
        await clickHotbarShortcut(slot[0] + 1) // lấy slot đầu tiên
    }
    window.pick_ball = auto_pixa;
})();