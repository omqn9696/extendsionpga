// ==UserScript==
// @name         JS Drawing canvas
// @namespace    pixels
// @icon         https://img.icons8.com/scribby/50/drawing.png
// @version      1.0
// @description  Highlight mines with countdown and visual indicators (only). No UGC or chat bubble.
// @author       Drayke
// @match        *://play.pixels.xyz/*
// @grant        none
// ==/UserScript==

(function () {
    "use strict";
    window.dist = 350;
    let lastHealthBarRect = null;
    let glowTime = 0;  //
    let blur = 0;
    const timerIcon = new Image();
    timerIcon.src = "https://d31ss916pli4td.cloudfront.net/game/ui/hud/hud_icon_energy.png";
    let timerIconLoaded = false;

    timerIcon.onload = () => { timerIconLoaded = true; };
    let  offsettime = Number(localStorage.getItem('offsettime') )|| 0;
    function getRemainingTimeInSeconds(endTimestamp) {
        const now = Date.now() + offsettime;
        return (endTimestamp - now) / 1000;
    }
    function create_ui_setting(){
        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                mutation.addedNodes.forEach((node) => {
                    if (
                        node.nodeType === 1 &&
                        node.classList.contains("SettingsWindow_container__n49mI")
                    ) {
                        setTimeout(() => insertOffsetUI(node), 30);
                    }
                });
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });

    }

    function insertOffsetUI(container) {
        const box = container.querySelector(".SettingsWindow_box__j8FBV");
        const closeBtn = container.querySelector(".commons_closeBtn__UobaL");
        if (!box || !closeBtn) {
            console.warn("Box hoặc CloseBtn chưa sẵn sàng");
            return;
        }
        if (box.querySelector("#offset-input")) return;
        const settingDiv = document.createElement("div");
        settingDiv.className = "SettingsWindow_setting__Rqjlp"
        const label = document.createElement("label");
        label.textContent = "Offset Time (ms): ";
        label.style.marginRight = "8px";
        const input = document.createElement("input");
        input.type = "number";
        input.id = "offset-input";
        input.value = localStorage.getItem("offsettime") || "0";
        input.style.width = "100px";
        input.style.marginRight = "8px";
        ["keydown", "keyup", "keypress"].forEach((eventName) => {
            input.addEventListener(eventName, (e) => e.stopPropagation());
        });

        const saveBtn = document.createElement("button");
        saveBtn.textContent = "Save";
        saveBtn.className = "commons_pushbutton__7Tpa3 commons_desktoponly__8Rp82";
        saveBtn.onclick = () => {
            localStorage.setItem("offsettime", input.value);
            offsettime = Number(input.value); // ← Cập nhật lại biến
            alert("Offset saved: " + input.value + " ms");
        };

        settingDiv.appendChild(label);
        settingDiv.appendChild(input);
        settingDiv.appendChild(saveBtn);
        closeBtn.parentElement?.insertBefore(settingDiv, closeBtn.nextSibling);
    }
    function getRemainingTimeString(totalInSeconds, mine = false) {
        if (totalInSeconds <= 0) return mine ? "ready" : "available";
        const days = Math.floor(totalInSeconds / (60 * 60 * 24));
        if (days > 0) return `${days} ${days > 1 ? "days" : "day"}`;
        const hours = Math.floor(totalInSeconds / 3600);
        const minutes = Math.floor((totalInSeconds % 3600) / 60);
        const seconds = Math.floor(totalInSeconds % 60);
        if (hours > 0) return `${hours}:${minutes.toString().padStart(2, "0")}`;
        if (minutes > 0) return `${minutes}:${seconds.toString().padStart(2, "0")}`;
        return `${seconds}s`;
    }

    function getNumberTrackerByName(e, name) {
        if (Array.isArray(e.generic.trackers)) {
            const stat = e.generic.trackers.find((s) => s.name === name);
            if (stat && stat.numeric) return Number(stat.value);
        }
        return -1;
    }

    function drawTextWithBG(ctx, txt, font, x, y) {
        ctx.save();
        ctx.font = font;
        ctx.textBaseline = "middle";
        ctx.textAlign = "center";

        const paddingX = 20;
        const paddingY = 15;

        const metrics = ctx.measureText(txt);
        const textWidth = metrics.width;
        const textHeight = metrics.actualBoundingBoxAscent + metrics.actualBoundingBoxDescent;

        ctx.fillStyle = "#ffffff";
        ctx.fillRect(
            x - textWidth / 2 - paddingX,
            y - textHeight / 2 - paddingY,
            textWidth + paddingX * 2,
            textHeight + paddingY * 2
        );

        ctx.strokeStyle = "red";
        ctx.lineWidth = 2;
        ctx.strokeText(txt, x, y);

        ctx.fillStyle = "red";
        ctx.fillText(txt, x, y);

        ctx.restore();
    }
    function drawAnimatedFlagAt(ctx, drawX, drawY) {
        const SPRITE_WIDTH = 122;
        const SPRITE_HEIGHT = 200;
        const TOTAL_FRAMES = 7;
        const FRAME_DURATION_MS = 1000 / 6;
        const POLE_WIDTH = 30;
        const FLAG_WIDTH = SPRITE_WIDTH - POLE_WIDTH;
        const PHYSICS_OFFSET_Y = 160;

        if (!window.flagSprite) {
            const img = new Image();
            img.src = "https://mesh-online-assets.s3.us-east-2.amazonaws.com/uploadedAssets/ugc/objects/obj_ugc-vietnamese-red-flag-iogv6tNY.png";
            window.flagSprite = img;
            return; // đợi load ảnh rồi render lại sau
        }

        if (!window.flagSprite.complete) return;

        // Vẽ cột đứng yên
        ctx.drawImage(
            window.flagSprite,
            0, 0,
            POLE_WIDTH, SPRITE_HEIGHT,
            drawX, drawY,
            POLE_WIDTH, SPRITE_HEIGHT
        );

        // Vẽ lá cờ động
        const frameIndex = Math.floor(Date.now() / FRAME_DURATION_MS) % TOTAL_FRAMES;
        const srcX = frameIndex * SPRITE_WIDTH + POLE_WIDTH;

        ctx.drawImage(
            window.flagSprite,
            srcX, 0,
            FLAG_WIDTH, SPRITE_HEIGHT,
            drawX + POLE_WIDTH, drawY,
            FLAG_WIDTH, SPRITE_HEIGHT
        );
    }
    function drawCircleOver(screenX, screenY, screenWidth, screenHeight, color, shadowColor, blur2, timerString, highlight) {
        const ctx = window.pga.drawing.canvasContext;
        ctx.save();

        ctx.shadowColor = shadowColor;
        ctx.shadowBlur = blur2;

        if (highlight === true) {
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(screenX + screenWidth / 2, screenY + screenHeight / 2, screenWidth / 2, 0, Math.PI * 3);
            ctx.fill();
        } else if (highlight === "me") {
            drawAnimatedFlagAt(ctx, (screenX + screenWidth / 2) - 20, (screenY + screenHeight / 2) - 200);
        }

        let font = "bold 25px Arial";
        if (window.pga.store.ui.isMiniMap) font = "bold 20px Arial";

        drawTextWithBG(ctx, timerString, font, screenX + screenWidth / 2, screenY + screenHeight / 2);
        ctx.restore();
    }

    function clearCanvas() {
        const ctx = window.pga.drawing.canvasContext;
        ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    }

    function highlightMines(events) {
        const pga2 = window.pga;
        const ctx = pga2.drawing.canvasContext;
        ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

        const roomScene = pga2.helpers.getRoomScene();
        if (!roomScene) return;

        for (let i = 0; i < events.length; i++) {
            const points = pga2.helpers.getDetailsOfEntities([events[i].mid]);
            if (!points || points.length === 0) continue;

            const { x, y, width, height } = points[0];
            const finishTime = events[i]?.generic?.displayInfo?.utcTarget;

            if (finishTime !== undefined) {
                const remainingTimeInSecond = getRemainingTimeInSeconds(finishTime);
                let timerString = getRemainingTimeString(remainingTimeInSecond, false);

                const {
                    x: screenX,
                    y: screenY,
                    width: screenWidth,
                    height: screenHeight,
                } = pga2.helpers.getScreenCoords(roomScene, x, y, width, height);

                let shadowColor = "rgba(255, 0, 0, 0.7)";
                let highlight = false;
                const color = "rgba(0, 130, 0, 0.5)";

                if (remainingTimeInSecond < 0) {
                    shadowColor = "rgba(0, 255, 0, 0.7)";
                    highlight = false;
                }

                if (getNumberTrackerByName(events[i], "inUseByMe") === 1) {
                    shadowColor = "rgba(0, 0, 255, 0.7)";
                    highlight = "me";
                }

                if (events[i].generic?.displayInfo?.format?.startsWith("Collect")) {
                    shadowColor = "rgba(0, 0, 255, 0.7)";
                    highlight = "me";
                    timerString = getRemainingTimeString(remainingTimeInSecond, true);
                }

                drawCircleOver(screenX, screenY, screenWidth, screenHeight, color, shadowColor, blur, timerString, highlight);
            }
        }
    }
    let lastPlayerList = [];
    function safeRenderPlayerList() {
        const currentUsername = window.pga.helpers.getRoomScene().selfPlayer.username;
        const players = window.pga.helpers.getRoomScene().stateManager.players;

        // lọc bỏ guest và chính mình
        const realPlayers = [];
        players.forEach(p => {
            if (!p.username.startsWith("Guest") && p.username !== currentUsername) {
                realPlayers.push(p.username);
            }
        });

        // chỉ render nếu có thay đổi
        if (JSON.stringify(realPlayers) === JSON.stringify(lastPlayerList)) {
            return;
        }
        lastPlayerList = realPlayers;

        renderPlayerList(realPlayers);
    }

    function renderPlayerList(playerList) {
        let wrapper = document.getElementById('player-list');
        if (!wrapper) {
            wrapper = document.createElement('div');
            wrapper.id = 'player-list';
            wrapper.style.position = 'fixed';
            wrapper.style.left = '10px';
            wrapper.style.bottom = '50%';
            wrapper.style.transform = 'translateY(50%)';
            wrapper.style.background = 'rgba(0,0,0,0.85)';
            wrapper.style.color = '#fff';
            wrapper.style.padding = '10px';
            wrapper.style.borderRadius = '8px';
            wrapper.style.fontFamily = 'Arial, sans-serif';
            wrapper.style.boxShadow = '0 2px 6px rgba(0,0,0,0.4)';
            wrapper.style.zIndex = '9999';

            const table = document.createElement('table');
            table.style.borderCollapse = 'collapse';
            wrapper.appendChild(table);
            document.body.appendChild(wrapper);
        }

        const table = wrapper.querySelector('table');
        table.innerHTML = '';

        // header: tổng số player thực
        const headerRow = document.createElement('tr');
        const headerCell = document.createElement('td');
        headerCell.textContent = `👷 (${playerList.length})`;
        headerCell.style.fontWeight = 'bold';
        headerCell.style.padding = '4px 8px';
        headerRow.appendChild(headerCell);
        table.appendChild(headerRow);

        // render danh sách
        playerList.forEach(username => {
            const row = document.createElement('tr');
            const cell = document.createElement('td');
            cell.textContent = username;
            cell.style.padding = '4px 8px';
            row.appendChild(cell);
            table.appendChild(row);
        });
    }

    function clearPlayerList() {
        const wrapper = document.getElementById('player-list');
        if (wrapper) wrapper.remove();
    }

    function waitForPGAHelpers(callback) {
        const interval = setInterval(() => {
            if (
                window.pga &&
                window.pga.helpers &&
                window.pga.helpers.getRoomScene &&
                window.pga.helpers.getRoomScene()?.selfPlayer
            ) {
                clearInterval(interval);
                callback();
            }
        }, 100);
    }

    function drawCircleFollowPlayer(radius = 300, color = "rgba(255,0,0,0.6)", lineWidth = 3) {
        const room = window.pga?.helpers?.getRoomScene?.();
        const ctx = window.pga?.drawing?.canvasContext;
        const cam = room?.cameras?.main;
        if (!room || !ctx || !cam) return;

        const self = room.selfPlayer;
        if (!self?.position) return;

        const { x: worldX, y: worldY } = self.position;

        // ======= TOA ĐỘ PLAYER (tâm vòng) =======
        const screen = window.pga.helpers.getScreenCoords(room, worldX, worldY, 64, 64);
        const centerX = screen.x + screen.width / 2;
        const centerY = screen.y + screen.height / 2;

        // ======= VẼ VÒNG TRÒN =======
        ctx.save();
        ctx.shadowColor = "rgba(255,0,0,0.8)";
        ctx.shadowBlur = 8;
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius * cam.zoom, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
    }

    function check_mine(radius = 300, color = "rgba(255,0,0,0.6)", lineWidth = 3) {
        const room = window.pga?.helpers?.getRoomScene?.();
        const ctx = window.pga?.drawing?.canvasContext;
        const cam = room?.cameras?.main;
        if (!room || !ctx || !cam) return;

        const self = room.selfPlayer;
        if (!self?.position) return;

        const { x: worldX, y: worldY } = self.position;

        // ======= TOA ĐỘ PLAYER (tâm vòng) =======
        const screen = window.pga.helpers.getScreenCoords(room, worldX, worldY, 64, 64);
        const centerX = screen.x + screen.width / 2;
        const centerY = screen.y + screen.height / 2;

        // ======= KIỂM TRA ENTITY MỎ TRONG VÒNG =======
        if (window.timerone === true ) {
            for (const ent of room.entities.values()) {
                const id = ent?.gameEntity?.id?.toLowerCase() || "";
                if (!id.includes("ent_mine_04")) continue;

                if (!ent.position) continue;

                // Toạ độ của mỏ
                const ms = window.pga.helpers.getScreenCoords(room, ent.position.x, ent.position.y, 64, 64);
                const ex = ms.x + ms.width / 2;
                const ey = ms.y + ms.height / 2;

                // Khoảng cách đúng (DX² + DY²)
                const dx = ex - centerX;
                const dy = ey - centerY;
                const distance = Math.sqrt(dx * dx + dy * dy);
                const nowUTC = Date.now();
                const utcTarget = ent?.currentState?.displayInfo?.utcTarget || 0;
                let remain = 0;
                if (utcTarget > nowUTC) {
                    remain = (utcTarget - nowUTC) / 1000;
                }
                //if(window.auto === 'on' && remain > 100){window.emitGameEvent("GO_HOME_TELE", !0);}
                // Nếu mỏ nằm trong vòng tròn
                if (distance <= (radius + 50 ) * cam.zoom && window.auto === 'on' &&  window.timerone && window.pga.helpers.getRoomScene().selfPlayer.bodyPosition.y < 3237) {

                    console.log("⛏️ Mỏ TRONG VÒNG → AutoMine:", id);

                    // chạy tuần tự để pick xong rồi mới auto mine
                    (async () => {
                        try {
                            let maxRetry = 3;
                            let retry = 0;

                            while (retry < maxRetry) {
                                await window.pick_ball("itm_pickaxe_04");
                                await new Promise(r => setTimeout(r, 120));
                                const slot = window.pga.helpers.getReduxValue().storage.selectedSlot;
                                const item = slot?.item ?? "";

                                if (item === "itm_pickaxe_04") {
                                    //console.log("🎉 Đã cầm Pickaxe thành công!");

                                    // chạy auto
                                    window.emitGameEvent("RELEASE_FROM_CURSOR", !0);

                                    // chống spam
                                    window.timerone = false;
                                    return;
                                }

                                retry++;
                                console.warn(`⚠️ Pickaxe chưa được cầm — thử lại (${retry}/${maxRetry})`);

                                // chờ 50–120ms rồi thử lại
                                await new Promise(r => setTimeout(r, 120));
                            }

                            console.error("❌ Thử nhiều lần nhưng không cầm được pickaxe!");

                        } catch (e) {
                            console.error("Lỗi khi pick → auto:", e);
                        }
                    })();
                    break;
                }
            }
        }
    }
    function drawDebugDots(points) {
    const ctx = window.pga.drawing.canvasContext;
    const room = window.pga.helpers.getRoomScene();

    for (const p of points) {
        const scr = window.pga.helpers.getScreenCoords(room, p.x - 8, p.y, 1, 1);

        ctx.save();
        ctx.fillStyle = "yellow";
        ctx.beginPath();
        ctx.arc(scr.x + 32, scr.y + 32, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }
}

    waitForPGAHelpers(() => {
        setInterval(() => {
            const entities = window.pga?.store?.ui?.mineEntitiesForHighlighting;
            const mapId = window.pga?.helpers.getReduxValue()?.game?.room?.mapId;
            if (
                mapId?.startsWith("pixelsNFTFarm") &&
                window.minebutton &&
                Array.isArray(entities) &&
                entities.length > 0
            ) {
                check_mine(300);
            }
        }, 200);
        create_ui_setting();

        function renderLoop() {
            const ctx = window.pga?.drawing?.canvasContext;
            const canvas = window.pga?.drawing?.canvas;
            const mapId = window.pga?.helpers.getReduxValue()?.game?.room?.mapId;

            // Nếu không có context → chờ frame sau
            if (!ctx || !canvas) {
                return requestAnimationFrame(renderLoop);
            }

            // ----- Dọn canvas mỗi frame -----
            clearCanvas()
            const others = getOtherPlayers();
            for (const p of others) drawPlayerName(p);
            // ===== MAP HEARTH =====
            if (mapId === "hearthhalls1") {
                glowTime += 0.15;  // glow animation
                draw_unicon(window.dist - 50);     // vẽ health bar
                //drawHealthHoverTooltip(ctx);  // tooltip
            }

            // ===== MAP FARM (Highlight Mines) =====
            const entities = window.pga?.store?.ui?.mineEntitiesForHighlighting;
            if (
                mapId?.startsWith("pixelsNFTFarm") &&
                window.minebutton &&
                Array.isArray(entities) &&
                entities.length > 0
            ) {

                highlightMines(entities);

                drawCircleFollowPlayer();
                const others = getOtherPlayers();
                for (const p of others) drawPlayerName(p);
            }
            drawTopCenterTimer();
            // Loop lại frame tiếp theo
                const line = window.player_position[window.pga?.gameState?.mapId]
                if(line){
                    drawDebugDots(line);
                }
            requestAnimationFrame(renderLoop);
        }

        // BẮT ĐẦU LOOP
        requestAnimationFrame(renderLoop);
    });
    function draw_unicon() {
        const entities = getHearthEntities()
        for (const ent of entities.values()) {
            if (ent.trackerState) {
                drawHealthBar(ent);
            }
        }
    }
    function getHearthEntities() { const room = window.pga?.helpers?.getRoomScene?.(); if (!room?.entities) return []; const list = [...room.entities.values()]; return list.filter(e => { const id = e?.gameEntity?.id || ""; return id === "ent_hearth_2" || id === "ent_hearth_1" || id === "ent_hearth_3" }); }
    function drawTrackerSimple(ent) {

        const state = ent?.trackerState;
        const ctx = window.pga.drawing.canvasContext;
        const room = window.pga?.helpers?.getRoomScene?.();

        if (!state || !ctx || !room) return;

        // ====== DATA ======
        const max = state.maxhealth || 1;
        const hp = state.health || 0;
        const percent = ((hp / max) * 100).toFixed(1) + "%";

        const deposits = state.deposits ?? 0;
        const sabotages = state.sabotages ?? 0;

        const lines = [
            `Health: ${percent}`,
            `Deposits: ${deposits}`,
            `Sabotages: ${sabotages}`
        ];

        // ====== VỊ TRÍ ======
        const scr = window.pga.helpers.getScreenCoords(
            room,
            ent.position.x + 50,
            ent.position.y ,
            1,
            1
        );
        if (!scr) return;

        ctx.save();
        ctx.font = "15px Arial";
        ctx.textBaseline = "top";

        // ====== TÍNH KÍCH THƯỚC BOX ======
        const padding = 10;
        const lineHeight = 20;

        let maxWidth = 0;
        for (const line of lines) {
            maxWidth = Math.max(maxWidth, ctx.measureText(line).width);
        }

        const boxW = maxWidth + padding * 2;
        const boxH = lines.length * lineHeight + padding * 2;

        const x = scr.x - boxW / 2; // căn giữa
        const y = scr.y;

        // ====== NỀN MỜ + BO GÓC ======
        const r = 8; // radius
        ctx.beginPath();
        ctx.fillStyle = "rgba(0,0,0,0.75)";
        ctx.strokeStyle = "#f5d742"; // vàng nhẹ
        ctx.lineWidth = 2;

        // bo góc
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + boxW - r, y);
        ctx.quadraticCurveTo(x + boxW, y, x + boxW, y + r);
        ctx.lineTo(x + boxW, y + boxH - r);
        ctx.quadraticCurveTo(x + boxW, y + boxH, x + boxW - r, y + boxH);
        ctx.lineTo(x + r, y + boxH);
        ctx.quadraticCurveTo(x, y + boxH, x, y + boxH - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);

        // bóng đổ
        ctx.shadowColor = "rgba(0,0,0,0.8)";
        ctx.shadowBlur = 10;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 3;

        ctx.fill();
        ctx.stroke();

        // ====== TEXT ======
        ctx.shadowBlur = 0;
        ctx.fillStyle = "white";

        let ty = y + padding;
        for (const line of lines) {
            ctx.fillText(line, x + padding, ty);
            ty += lineHeight;
        }

        ctx.restore();
    }
    function drawPathFixed(points) {
    const ctx = window.pga?.drawing?.canvasContext;
    const room = window.pga?.helpers?.getRoomScene?.();
    if (!ctx || !room || !Array.isArray(points) || points.length < 2) return;

    ctx.save();

    ctx.strokeStyle = "rgba(0,255,0,0.9)"; // xanh neon
    ctx.lineWidth = 4;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    ctx.shadowColor = "rgba(0,0,0,0.8)";
    ctx.shadowBlur = 8;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;

    ctx.beginPath();

    for (let i = 0; i < points.length; i++) {
        const p = points[i];

        const scr = window.pga.helpers.getScreenCoords(
            room,
            p.x,
            p.y,
            64,
            64
        );

        // KHÔNG trừ camera nữa vì getScreenCoords đã tính camera
        const sx = scr.x + scr.width / 2;
        const sy = scr.y + scr.height / 2;

        if (i === 0) ctx.moveTo(sx, sy);
        else ctx.lineTo(sx, sy);
    }

    ctx.stroke();
    ctx.restore();
}

    function drawPathSimple(points) {
        const ctx = window.pga?.drawing?.canvasContext;
        const room = window.pga?.helpers?.getRoomScene?.();

        if (!ctx || !room || !Array.isArray(points) || points.length < 2) return;

        ctx.save();

        // ===== STYLE ĐƯỜNG =====
        ctx.strokeStyle = "rgba(0, 255, 0, 0.9)"; // xanh neon
        ctx.lineWidth = 4;
        ctx.lineJoin = "round";   // bo góc mịn
        ctx.lineCap = "round";    // đầu line tròn

        // ===== SHADOW =====
        ctx.shadowColor = "rgba(0, 0, 0, 0.9)";
        ctx.shadowBlur = 8;
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 3;

        ctx.beginPath();

        for (let i = 0; i < points.length; i++) {
            const p = points[i];

            // convert WORLD → SCREEN
            const scr = window.pga.helpers.getScreenCoords(
                room,
                p.x,
                p.y,
                64,
                64
            );

            const sx = scr.x + scr.width / 2 - room.cameras.main.scrollX;
            const sy = scr.y + scr.height / 2 - room.cameras.main.scrollY;

            if (i === 0) {
                ctx.moveTo(sx, sy);
            } else {
                ctx.lineTo(sx, sy);
            }
        }

        ctx.stroke();
        ctx.restore();
    }

    function drawHealthBar(ent) {
        const state = ent?.trackerState;
        const ctx = window.pga?.drawing?.canvasContext;
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!state || !ctx || !room) return;

        const max = state.maxhealth || 1;
        const hp = state.health || 0;
        const percent = Math.max(0, Math.min(1, hp / max));

        // WORLD → SCREEN
        const scr = window.pga.helpers.getScreenCoords(
            room,
            ent.position.x + 10,
            ent.position.y - 60,
            1,
            1
        );
        if (!scr) return;

        ctx.save();
        ctx.imageSmoothingEnabled = false;

        // SIZE
        const barW = 180;
        const barH = 22;

        const x = scr.x;
        const y = scr.y;

        // === LƯU RECT để detect hover ===
        lastHealthBarRect = { x, y, w: barW, h: barH, percent };

        // === DRAW FRAME ===
        ctx.fillStyle = "#7d7d9b";
        ctx.fillRect(x, y, barW, barH);

        ctx.fillStyle = "#2e2e45";
        ctx.fillRect(x + 3, y + 3, barW - 6, barH - 6);

        // === FILL THE BAR ===
        const fillWidth = (barW - 6) * percent;

        ctx.fillStyle = percent > 0.5 ? "#7cff78"
        : percent > 0.25 ? "#ffd966"
        : "#ff5858";

        ctx.fillRect(x + 3, y + 3, fillWidth, barH - 6);

        //drawHeartIcon(ctx, x - 28, y - 1);

        ctx.restore();
    }
    function drawHeartIcon(ctx, x, y) {
        ctx.save();
        ctx.fillStyle = "#ff4d6d";
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;

        // Vẽ trái tim đơn giản
        ctx.beginPath();
        ctx.moveTo(x + 10, y + 4);
        ctx.bezierCurveTo(x + 4, y - 2, x - 2, y + 6, x + 10, y + 16);
        ctx.bezierCurveTo(x + 22, y + 6, x + 16, y - 2, x + 10, y + 4);
        ctx.fill();
        ctx.stroke();

        ctx.restore();
    }function drawHealthHoverTooltip(ctx) {
        if (!lastHealthBarRect) return;

        const { x, y, w, h, percent } = lastHealthBarRect;

        // check hover
        const hovering =
              mouseX >= x &&
              mouseX <= x + w &&
              mouseY >= y &&
              mouseY <= y + h;

        if (!hovering) return;

        ctx.save();
        ctx.font = "14px Arial";
        ctx.textBaseline = "top";
        ctx.fillStyle = "rgba(0,0,0,0.75)";
        ctx.strokeStyle = "#ffec8b";
        ctx.lineWidth = 2;

        const text = (percent * 100).toFixed(1) + "%";
        const pad = 6;
        const tw = ctx.measureText(text).width + pad * 2;
        const th = 22;

        const tx = mouseX + 10;
        const ty = mouseY - 30;

        // background
        ctx.beginPath();
        ctx.fillRect(tx, ty, tw, th);
        ctx.strokeRect(tx, ty, tw, th);

        ctx.fillStyle = "white";
        ctx.fillText(text, tx + pad, ty + 4);

        ctx.restore();
    }
    function decColor(n){
        return "#" + n.toString(16).padStart(6,"0");
    }
    function drawPlayerName(player) {
        const ctx = window.pga?.drawing?.canvasContext;
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!ctx || !room) return;

        const data = player?.characterHelper?.characterData;
        if (!data) return;

        const name = data.label || "Unknown";

        const pos = player?.bodyPosition;
        if (!pos) return;
        const offy = player?.offsetY
        const offx = player?.offsetX

        // WORLD → SCREEN
        const scr = window.pga.helpers.getScreenCoords(
            room,
            pos.x + offx,
            pos.y - (offy + 30),   // đặt tên lên trên đầu nhân vật
            1,
            1
        );
        if (!scr) return;

        ctx.save();
        ctx.font = "bold 9px 'Press Start 2P'";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.imageSmoothingEnabled = false;

        // tính kích thước box
        const paddingX = 12;
        const paddingY = 6;
        const textW = ctx.measureText(name).width;
        const boxW = textW + paddingX * 2;
        const boxH = 24;

        const x = scr.x - boxW / 2;
        const y = scr.y;

        //
        // ======= VẼ KHUNG BOX =======
        //

        // bo góc
        const r = 6;

        // Màu nền giống game
        ctx.fillStyle = decColor(4004513);

        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + boxW - r, y);
        ctx.quadraticCurveTo(x + boxW, y, x + boxW, y + r);
        ctx.lineTo(x + boxW, y + boxH - r);
        ctx.quadraticCurveTo(x + boxW, y + boxH, x + boxW - r, y + boxH);
        ctx.lineTo(x + r, y + boxH);
        ctx.quadraticCurveTo(x, y + boxH, x, y + boxH - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.fill();

        //
        // ======= VẼ MŨI NHỌN (triangle) =======
        //

        const triW = 14;
        const triH = 8;
        const triX = scr.x;
        const triY = y + boxH;

        ctx.beginPath();
        ctx.moveTo(triX - triW / 2, triY);
        ctx.lineTo(triX + triW / 2, triY);
        ctx.lineTo(triX, triY + triH);
        ctx.closePath();
        ctx.fill();

        //
        // ======= VIỀN TRẮNG =======
        //
        ctx.strokeStyle = decColor(4004513);
        ctx.lineWidth = 1;

        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + boxW - r, y);
        ctx.quadraticCurveTo(x + boxW, y, x + boxW, y + r);
        ctx.lineTo(x + boxW, y + boxH - r);
        ctx.quadraticCurveTo(x + boxW, y + boxH, x + boxW - r, y + boxH);
        ctx.lineTo(x + r, y + boxH);
        ctx.quadraticCurveTo(x, y + boxH, x, y + boxH - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.stroke();

        // viền mũi nhọn
        ctx.beginPath();
        ctx.moveTo(triX - triW / 2, triY);
        ctx.lineTo(triX + triW / 2, triY);
        ctx.lineTo(triX, triY + triH);
        ctx.closePath();
        ctx.stroke();

        //
        // ======= TEXT =======
        //
        ctx.fillStyle = decColor(16777215);;
        ctx.fillText(name, scr.x, y + boxH / 2);

        ctx.restore();
    }
    function getOtherPlayers() {
        const room = window.pga?.helpers?.getRoomScene?.();
        if (!room || !room.otherPlayers) return [];
        return [...room.otherPlayers.values()];
    }
    function formatTimer(endTime) {
        let remain = endTime - Date.now();
        if (remain < 0) remain = 0;

        const sec = Math.floor(remain / 1000);
        const m = Math.floor(sec / 60);
        const s = sec % 60;
        const h = Math.floor(m / 60);
        const mm = m % 60;

        // ≥ 1 hour  → "H:mm"
        if (h >= 1) {
            return `${h}h:${mm.toString().padStart(2, "0")}p`;
        }

        // < 60 minutes → "mm:ss"
        return `${mm}p:${s.toString().padStart(2, "0")}s`;
    }
    function drawTopCenterTimer() {
        if (!timerIconLoaded) return;
        if (!window.timerscheck || window.timerscheck.length === 0) return;
        const ctx = window.pga.drawing.canvasContext;
        const canvas = window.pga?.drawing?.canvas;
        const data = window.timerscheck[0];
        const text = formatTimer(data.endTime);

        // Layout
        const ICON_W = 32;
        const ICON_H = 32;
        const padding = 3;
        const spacing = 3;

        ctx.font = "bold 9px 'Press Start 2P'";
        const textW = ctx.measureText(text).width;
        const textH = 10;

        const boxW = Math.max(ICON_W, textW) + padding * 2;
        const boxH = ICON_H + textH + spacing + padding * 2;

        const boxX = (canvas.width - boxW) / 2;
        const boxY = 8; // top

        // ===== Background bo góc =====
        ctx.save();
        ctx.fillStyle = "rgba(0,0,0,0.55)";
        ctx.strokeStyle = "rgba(255,255,255,0.3)";
        ctx.lineWidth = 2;

        const r = 10;
        ctx.beginPath();
        ctx.moveTo(boxX + r, boxY);
        ctx.lineTo(boxX + boxW - r, boxY);
        ctx.quadraticCurveTo(boxX + boxW, boxY, boxX + boxW, boxY + r);
        ctx.lineTo(boxX + boxW, boxY + boxH - r);
        ctx.quadraticCurveTo(boxX + boxW, boxY + boxH, boxX + boxW - r, boxY + boxH);
        ctx.lineTo(boxX + r, boxY + boxH);
        ctx.quadraticCurveTo(boxX, boxY + boxH, boxX, boxY + boxH - r);
        ctx.lineTo(boxX, boxY + r);
        ctx.quadraticCurveTo(boxX, boxY, boxX + r, boxY);

        // Shadow nhẹ
        ctx.shadowColor = "rgba(0,0,0,0.6)";
        ctx.shadowBlur = 8;
        ctx.shadowOffsetY = 3;

        ctx.fill();
        ctx.stroke();
        ctx.restore();

        // ===== Draw Icon =====
        const iconX = boxX + (boxW - ICON_W) / 2;
        const iconY = boxY + padding;

        ctx.drawImage(timerIcon, iconX, iconY, ICON_W, ICON_H);

        // ===== Draw Text =====
        ctx.fillStyle = "white";
        ctx.font = "bold 9px 'Press Start 2P'";
        ctx.textAlign = "center";

        ctx.fillText(text, boxX + boxW / 2, iconY + ICON_H + spacing + textH);
    }

})();